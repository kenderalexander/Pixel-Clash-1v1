package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.TetrisEngine
import com.example.model.Cell
import com.example.model.PieceType
import com.example.model.PlayerState
import com.example.model.Tetromino
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Pixel Clash 1v1", appName)
    }

    @Test
    fun `pieces include only 4 straight horizontal pieces`() {
        val allPieces = PieceType.ALL_PIECES.toList()

        // 1 Quadradinho (1x1)
        assertTrue(allPieces.contains(PieceType.LINE_1))
        assertEquals(1, PieceType.LINE_1.blockCount)

        // 2 Quadradinhos na horizontal (1x2)
        assertTrue(allPieces.contains(PieceType.LINE_2))
        assertEquals(2, PieceType.LINE_2.blockCount)

        // 3 Quadradinhos na horizontal (1x3)
        assertTrue(allPieces.contains(PieceType.LINE_3))
        assertEquals(3, PieceType.LINE_3.blockCount)

        // 4 Quadradinhos na horizontal (1x4)
        assertTrue(allPieces.contains(PieceType.LINE_4))
        assertEquals(4, PieceType.LINE_4.blockCount)

        // Exactly 4 piece types in total
        assertEquals(4, allPieces.size)
    }

    @Test
    fun `attack mechanic calculates 75 percent of eliminated squares`() {
        // 1 line = 10 squares -> 75% = 7 garbage blocks
        assertEquals(7, TetrisEngine.calculateAttackBlocks(1, combo = 0))
        // 2 lines = 20 squares -> 75% = 15 garbage blocks
        assertEquals(15, TetrisEngine.calculateAttackBlocks(2, combo = 0))
        // 3 lines = 30 squares -> 75% = 22 garbage blocks
        assertEquals(22, TetrisEngine.calculateAttackBlocks(3, combo = 0))
        // 4 lines = 40 squares -> 75% = 30 garbage blocks
        assertEquals(30, TetrisEngine.calculateAttackBlocks(4, combo = 0))
    }

    @Test
    fun `attack squares are correctly partitioned into 1x2 and 1x3 pieces`() {
        val pieces7 = TetrisEngine.partitionAttackIntoPieces(7)
        assertEquals(7, pieces7.sum())
        assertTrue(pieces7.all { it == 2 || it == 3 })

        val pieces15 = TetrisEngine.partitionAttackIntoPieces(15)
        assertEquals(15, pieces15.sum())
        assertTrue(pieces15.all { it == 2 || it == 3 })

        val pieces30 = TetrisEngine.partitionAttackIntoPieces(30)
        assertEquals(30, pieces30.sum())
        assertTrue(pieces30.all { it == 2 || it == 3 })
    }

    @Test
    fun `progressive falling 1x2 and 1x3 garbage pieces descend from top and lock into board`() {
        val emptyBoard = List(PlayerState.BOARD_ROWS) { List<Cell?>(PlayerState.BOARD_COLS) { null } }
        val wave = TetrisEngine.createFallingGarbagePieceWave(emptyBoard, emptyList(), 7)
        assertTrue(wave.isNotEmpty())

        // Verify piece sizes are only 2 or 3
        assertTrue(wave.all { it.size == 2 || it.size == 3 })

        // Simulate stepping falling garbage pieces down
        var currentBoard = emptyBoard
        var currentFalling = wave

        for (step in 0 until 40) {
            val result = TetrisEngine.stepFallingGarbagePieces(currentBoard, currentFalling)
            currentBoard = result.newBoard
            currentFalling = result.remainingFalling
            if (currentFalling.isEmpty()) break
        }

        // After falling steps complete, all 7 blocks must have locked into currentBoard
        var lockedCount = 0
        for (r in 0 until PlayerState.BOARD_ROWS) {
            for (c in 0 until PlayerState.BOARD_COLS) {
                if (currentBoard[r][c] != null && currentBoard[r][c]!!.isGarbage) {
                    lockedCount++
                }
            }
        }
        assertEquals(7, lockedCount)
    }

    @Test
    fun `movement and rotation work correctly with straight pieces`() {
        val emptyBoard = List(PlayerState.BOARD_ROWS) { List<Cell?>(PlayerState.BOARD_COLS) { null } }
        val spawned = Tetromino.spawn(PieceType.LINE_3)
        val movedRight = TetrisEngine.tryMove(emptyBoard, spawned, 1, 0)
        assertNotNull(movedRight)
        assertEquals(spawned.x + 1, movedRight!!.x)

        val rotated = TetrisEngine.tryRotate(emptyBoard, spawned)
        assertNotNull(rotated)
        assertEquals(1, rotated!!.rotation)
    }
}
