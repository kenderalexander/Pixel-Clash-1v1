package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

class SoundManager(context: Context) {
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val audioScope = CoroutineScope(Dispatchers.Default)
    var isEnabled: Boolean = true
        set(value) {
            field = value
            if (!value) {
                stopBgm()
            }
        }

    private var bgmJob: Job? = null

    // BGM Melodies
    private val chiptuneArcade = listOf(
        Pair(659.25f, 200L), Pair(493.88f, 100L), Pair(523.25f, 100L), Pair(587.33f, 200L),
        Pair(523.25f, 100L), Pair(493.88f, 100L), Pair(440.00f, 200L), Pair(440.00f, 100L),
        Pair(523.25f, 100L), Pair(659.25f, 200L), Pair(587.33f, 100L), Pair(523.25f, 100L),
        Pair(493.88f, 300L), Pair(523.25f, 100L), Pair(587.33f, 200L), Pair(659.25f, 200L),
        Pair(523.25f, 200L), Pair(440.00f, 200L), Pair(440.00f, 300L)
    )

    private val chiptuneRush = listOf(
        Pair(440.00f, 150L), Pair(440.00f, 150L), Pair(523.25f, 150L), Pair(587.33f, 150L),
        Pair(659.25f, 150L), Pair(659.25f, 150L), Pair(587.33f, 150L), Pair(523.25f, 150L)
    )

    private val chiptuneSynth = listOf(
        Pair(220.00f, 400L), Pair(261.63f, 400L), Pair(329.63f, 400L), Pair(293.66f, 400L)
    )

    fun startBgm(bgmId: String = "arcade") {
        if (!isEnabled || bgmJob?.isActive == true) return
        val melody = when (bgmId) {
            "rush" -> chiptuneRush
            "synth" -> chiptuneSynth
            else -> chiptuneArcade
        }
        bgmJob = audioScope.launch {
            while (isEnabled) {
                for ((freq, durationMs) in melody) {
                    if (!isEnabled) break
                    playTone(
                        frequency = freq,
                        durationMs = (durationMs * 0.85f).toInt(),
                        wave = if (bgmId == "synth") WaveType.SAWTOOTH else WaveType.SQUARE,
                        volume = 0.12f
                    )
                    delay(durationMs)
                }
            }
        }
    }

    fun stopBgm() {
        bgmJob?.cancel()
        bgmJob = null
    }

    fun playMove() {
        if (!isEnabled) return
        vibrate(10)
        audioScope.launch {
            playTone(frequency = 650f, durationMs = 20, wave = WaveType.SQUARE, volume = 0.2f)
        }
    }

    fun playRotate() {
        if (!isEnabled) return
        vibrate(15)
        audioScope.launch {
            playChirp(startFreq = 800f, endFreq = 1200f, durationMs = 30, volume = 0.25f)
        }
    }

    fun playDrop() {
        if (!isEnabled) return
        vibrate(35)
        audioScope.launch {
            playDecayingTone(startFreq = 320f, endFreq = 40f, durationMs = 80, volume = 0.55f)
        }
    }

    fun playLineClear(linesCount: Int) {
        if (!isEnabled) return
        vibrate(linesCount * 35L)
        audioScope.launch {
            val arpeggio = when (linesCount) {
                1 -> listOf(523.25f, 659.25f, 783.99f) // C5, E5, G5
                2 -> listOf(523.25f, 659.25f, 783.99f, 1046.50f) // C5, E5, G5, C6
                3 -> listOf(523.25f, 659.25f, 783.99f, 1046.50f, 1318.51f) // C5, E5, G5, C6, E6
                else -> listOf(523.25f, 659.25f, 783.99f, 1046.50f, 1318.51f, 1567.98f) // TETRIS FANFARE
            }
            for (freq in arpeggio) {
                playTone(frequency = freq, durationMs = 45, wave = WaveType.SQUARE, volume = 0.45f)
            }
        }
    }

    fun playAttack() {
        if (!isEnabled) return
        vibrate(50)
        audioScope.launch {
            // Rising laser attack sound
            playChirp(startFreq = 300f, endFreq = 1600f, durationMs = 110, volume = 0.45f)
        }
    }

    fun playGarbageIncoming() {
        if (!isEnabled) return
        vibrate(80)
        audioScope.launch {
            // Rapid 8-bit alarm siren
            val alarmFreqs = listOf(880f, 440f, 880f, 440f, 880f)
            for (freq in alarmFreqs) {
                playTone(frequency = freq, durationMs = 40, wave = WaveType.SAWTOOTH, volume = 0.45f)
            }
        }
    }

    fun playVictory() {
        if (!isEnabled) return
        stopBgm()
        vibrate(120)
        audioScope.launch {
            val victoryNotes = listOf(
                Pair(523.25f, 90),  // C5
                Pair(659.25f, 90),  // E5
                Pair(783.99f, 90),  // G5
                Pair(1046.50f, 200) // High C6
            )
            for ((note, dur) in victoryNotes) {
                playTone(frequency = note, durationMs = dur, wave = WaveType.SQUARE, volume = 0.5f)
            }
        }
    }

    fun playGameOver() {
        if (!isEnabled) return
        stopBgm()
        vibrate(80)
        audioScope.launch {
            val defeatNotes = listOf(
                Pair(440.00f, 120),
                Pair(370.00f, 120),
                Pair(311.13f, 140),
                Pair(220.00f, 250)
            )
            for ((note, dur) in defeatNotes) {
                playTone(frequency = note, durationMs = dur, wave = WaveType.TRIANGLE, volume = 0.4f)
            }
        }
    }

    private fun vibrate(durationMs: Long) {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(
                            durationMs.coerceIn(5, 200),
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {
            // Fallback
        }
    }

    private enum class WaveType {
        SQUARE,
        TRIANGLE,
        SAWTOOTH
    }

    private fun playTone(
        frequency: Float,
        durationMs: Int,
        wave: WaveType,
        volume: Float
    ) {
        try {
            val sampleRate = 22050
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            if (numSamples <= 0) return
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val time = i.toDouble() / sampleRate
                val angle = 2.0 * Math.PI * frequency * time
                val sampleValue = when (wave) {
                    WaveType.SQUARE -> if (sin(angle) >= 0) 1.0 else -1.0
                    WaveType.TRIANGLE -> (2.0 / Math.PI) * Math.asin(sin(angle))
                    WaveType.SAWTOOTH -> (2.0 * (time * frequency - Math.floor(time * frequency + 0.5)))
                }

                val envelope = when {
                    i < numSamples * 0.1 -> i / (numSamples * 0.1)
                    i > numSamples * 0.7 -> (numSamples - i) / (numSamples * 0.3)
                    else -> 1.0
                }

                val finalSample = (sampleValue * envelope * Short.MAX_VALUE * volume).toInt()
                buffer[i] = finalSample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 10)
            track.release()
        } catch (_: Exception) {
            // AudioTrack fallback
        }
    }

    private fun playChirp(
        startFreq: Float,
        endFreq: Float,
        durationMs: Int,
        volume: Float
    ) {
        try {
            val sampleRate = 22050
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            if (numSamples <= 0) return
            val buffer = ShortArray(numSamples)

            var phase = 0.0
            for (i in 0 until numSamples) {
                val t = i.toDouble() / numSamples
                val currentFreq = startFreq + (endFreq - startFreq) * t
                phase += 2.0 * Math.PI * currentFreq / sampleRate
                val sampleValue = if (sin(phase) >= 0) 1.0 else -1.0
                val envelope = if (i > numSamples * 0.8) (numSamples - i) / (numSamples * 0.2) else 1.0
                val finalSample = (sampleValue * envelope * Short.MAX_VALUE * volume).toInt()
                buffer[i] = finalSample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 10)
            track.release()
        } catch (_: Exception) {
            // Fallback
        }
    }

    private fun playDecayingTone(
        startFreq: Float,
        endFreq: Float,
        durationMs: Int,
        volume: Float
    ) {
        try {
            val sampleRate = 22050
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            if (numSamples <= 0) return
            val buffer = ShortArray(numSamples)

            var phase = 0.0
            for (i in 0 until numSamples) {
                val t = i.toDouble() / numSamples
                val currentFreq = startFreq + (endFreq - startFreq) * t
                phase += 2.0 * Math.PI * currentFreq / sampleRate
                val sampleValue = sin(phase)
                val envelope = (1.0 - t) * (1.0 - t)
                val finalSample = (sampleValue * envelope * Short.MAX_VALUE * volume).toInt()
                buffer[i] = finalSample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 10)
            track.release()
        } catch (_: Exception) {
            // Fallback
        }
    }
}
