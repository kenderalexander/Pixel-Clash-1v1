package com.example.model

import androidx.compose.ui.graphics.Color

enum class PieceType(
    val displayName: String,
    val primaryColor: Color,
    val highlightColor: Color,
    val shadowColor: Color,
    val blockCount: Int,
    val rotations: List<List<List<Int>>>
) {
    // 1 QUADRADINHO (1x1)
    LINE_1(
        displayName = "1-BLOCO",
        primaryColor = Color(0xFFFFD600),
        highlightColor = Color(0xFFFFFF8D),
        shadowColor = Color(0xFFFFAB00),
        blockCount = 1,
        rotations = listOf(
            listOf(listOf(1)),
            listOf(listOf(1)),
            listOf(listOf(1)),
            listOf(listOf(1))
        )
    ),

    // 2 QUADRADINHOS NA HORIZONTAL (1x2)
    LINE_2(
        displayName = "2-RETAS",
        primaryColor = Color(0xFFFF4081),
        highlightColor = Color(0xFFFF80AB),
        shadowColor = Color(0xFFC2185B),
        blockCount = 2,
        rotations = listOf(
            // Horizontal (1x2)
            listOf(listOf(1, 1)),
            // Vertical (2x1)
            listOf(listOf(1), listOf(1)),
            // Horizontal (1x2)
            listOf(listOf(1, 1)),
            // Vertical (2x1)
            listOf(listOf(1), listOf(1))
        )
    ),

    // 3 QUADRADINHOS NA HORIZONTAL (1x3)
    LINE_3(
        displayName = "3-RETAS",
        primaryColor = Color(0xFF00E5FF),
        highlightColor = Color(0xFF84FFFF),
        shadowColor = Color(0xFF00B0FF),
        blockCount = 3,
        rotations = listOf(
            // Horizontal (1x3)
            listOf(listOf(1, 1, 1)),
            // Vertical (3x1)
            listOf(listOf(1), listOf(1), listOf(1)),
            // Horizontal (1x3)
            listOf(listOf(1, 1, 1)),
            // Vertical (3x1)
            listOf(listOf(1), listOf(1), listOf(1))
        )
    ),

    // 4 QUADRADINHOS NA HORIZONTAL (1x4)
    LINE_4(
        displayName = "4-RETAS",
        primaryColor = Color(0xFF7C4DFF),
        highlightColor = Color(0xFFB388FF),
        shadowColor = Color(0xFF512DA8),
        blockCount = 4,
        rotations = listOf(
            // Horizontal (1x4)
            listOf(listOf(1, 1, 1, 1)),
            // Vertical (4x1)
            listOf(listOf(1), listOf(1), listOf(1), listOf(1)),
            // Horizontal (1x4)
            listOf(listOf(1, 1, 1, 1)),
            // Vertical (4x1)
            listOf(listOf(1), listOf(1), listOf(1), listOf(1))
        )
    );

    fun getShape(rotation: Int): List<List<Int>> {
        val normalized = ((rotation % rotations.size) + rotations.size) % rotations.size
        return rotations[normalized]
    }

    companion object {
        // Aliases for compatibility
        val MONOMINO: PieceType get() = LINE_1
        val DOMINO: PieceType get() = LINE_2
        val I_TROMINO: PieceType get() = LINE_3
        val I: PieceType get() = LINE_4
        val DOT: PieceType get() = LINE_1

        val ALL_PIECES = entries.toTypedArray()

        /**
         * Returns a 100% pure random piece among the 4 straight shapes (1x1, 1x2, 1x3, 1x4)
         * without fixed bag cycles or pre-determined repeating sequences.
         */
        fun getRandomPiece(): PieceType {
            return entries.random()
        }

        fun createRandomBag(): List<PieceType> {
            return entries.toList().shuffled()
        }
    }
}
