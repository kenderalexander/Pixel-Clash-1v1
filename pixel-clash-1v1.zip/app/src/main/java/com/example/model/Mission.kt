package com.example.model

data class Mission(
    val id: String,
    val title: String,
    val description: String,
    val reward: Int,
    val progress: Int,
    val goal: Int,
    val isCompleted: Boolean,
    val isClaimed: Boolean
)
