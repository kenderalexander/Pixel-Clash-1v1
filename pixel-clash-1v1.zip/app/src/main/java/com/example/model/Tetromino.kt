package com.example.model

data class Tetromino(
    val type: PieceType,
    val x: Int,
    val y: Int,
    val rotation: Int = 0
) {
    val shape: List<List<Int>>
        get() = type.getShape(rotation)

    /**
     * Returns list of absolute (boardX, boardY) coordinates occupied by this piece
     */
    fun getOccupiedCoordinates(): List<Pair<Int, Int>> {
        val coords = mutableListOf<Pair<Int, Int>>()
        val currentShape = shape
        for (r in currentShape.indices) {
            for (c in currentShape[r].indices) {
                if (currentShape[r][c] != 0) {
                    coords.add(Pair(x + c, y + r))
                }
            }
        }
        return coords
    }

    fun move(dx: Int, dy: Int): Tetromino = copy(x = x + dx, y = y + dy)

    fun rotateClockwise(): Tetromino = copy(rotation = (rotation + 1) % 4)

    fun rotateCounterClockwise(): Tetromino = copy(rotation = (rotation + 3) % 4)

    companion object {
        fun spawn(type: PieceType, boardWidth: Int = 10): Tetromino {
            val shape = type.getShape(0)
            val pieceWidth = shape[0].size
            val startX = (boardWidth - pieceWidth) / 2
            val startY = 0
            return Tetromino(type = type, x = startX, y = startY, rotation = 0)
        }
    }
}
