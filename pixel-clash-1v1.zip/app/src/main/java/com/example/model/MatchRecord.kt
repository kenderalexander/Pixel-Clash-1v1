package com.example.model

data class MatchRecord(
    val id: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val gameMode: String = "",
    val isVictory: Boolean = false,
    val linesCleared: Int = 0,
    val attacksSent: Int = 0,
    val durationSeconds: Long = 0L,
    val score: Int = 0,
    val maxCombo: Int = 0
)

data class AggregatedStats(
    val totalMatches: Int = 0,
    val totalWins: Int = 0,
    val totalLosses: Int = 0,
    val winRatePercent: Int = 0,
    val totalLinesCleared: Int = 0,
    val totalAttacksSent: Int = 0,
    val totalPlayTimeSeconds: Long = 0L,
    val highScore: Int = 0
)
