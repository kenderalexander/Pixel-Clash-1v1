package com.example.model

data class ShopItem(
    val id: String,
    val name: String,
    val itemCategory: String, // "blocos", "fundos", "efeitos", "musicas"
    val price: Int,
    val iconRes: String // Simplified as a placeholder string for now
)

data class PlayerInventory(
    val coins: Int = 0,
    val boughtItems: List<String> = emptyList(),
    val equippedItems: Map<String, String> = emptyMap() // category -> itemId
)
