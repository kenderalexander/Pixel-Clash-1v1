package com.example.engine

import com.example.model.Cell
import com.example.model.CpuDifficulty
import com.example.model.PieceType
import com.example.model.PlayerState
import com.example.model.Tetromino
import kotlin.math.abs
import kotlin.random.Random

class OpponentAI {
    data class MoveDecision(
        val targetX: Int,
        val targetRotation: Int,
        val score: Double
    )

    /**
     * Determines the optimal column and rotation for the opponent's current piece
     * according to selected CPU difficulty.
     */
    fun findBestMove(
        board: List<List<Cell?>>,
        pieceType: PieceType,
        difficulty: CpuDifficulty = CpuDifficulty.MEDIUM
    ): MoveDecision {
        var bestDecision = MoveDecision(
            targetX = (PlayerState.BOARD_COLS - pieceType.getShape(0)[0].size) / 2,
            targetRotation = 0,
            score = -999999.0
        )

        val rotationCount = pieceType.rotations.size

        for (rot in 0 until rotationCount) {
            val shape = pieceType.getShape(rot)

            for (col in -(shape.size - 1) until PlayerState.BOARD_COLS) {
                val testPiece = Tetromino(type = pieceType, x = col, y = 0, rotation = rot)
                if (!TetrisEngine.isValidPosition(board, testPiece)) {
                    val testPiece2 = Tetromino(type = pieceType, x = col, y = -1, rotation = rot)
                    if (!TetrisEngine.isValidPosition(board, testPiece2)) continue
                }

                val ghost = TetrisEngine.calculateGhost(board, testPiece)
                if (ghost.y < 0) continue

                val simulated = TetrisEngine.lockPiece(board, ghost)
                val baseScore = evaluateBoard(simulated.newBoard, simulated.clearedRows.size, pieceType, ghost, difficulty)

                val jitterRange = when (difficulty) {
                    CpuDifficulty.EASY -> 12.0
                    CpuDifficulty.MEDIUM -> 3.0
                    CpuDifficulty.HARD -> 0.5
                }
                val jitter = Random.nextDouble(-jitterRange, jitterRange)
                val totalScore = baseScore + jitter

                if (totalScore > bestDecision.score) {
                    bestDecision = MoveDecision(
                        targetX = col,
                        targetRotation = rot,
                        score = totalScore
                    )
                }
            }
        }

        return bestDecision
    }

    private fun evaluateBoard(
        board: List<List<Cell?>>,
        linesCleared: Int,
        pieceType: PieceType,
        placedPiece: Tetromino,
        difficulty: CpuDifficulty
    ): Double {
        var score = 0.0

        val lineBonus = when (linesCleared) {
            1 -> if (difficulty == CpuDifficulty.HARD) 40.0 else 20.0
            2 -> if (difficulty == CpuDifficulty.HARD) 120.0 else 80.0
            3 -> if (difficulty == CpuDifficulty.HARD) 280.0 else 180.0
            4 -> if (difficulty == CpuDifficulty.HARD) 500.0 else 350.0
            else -> 0.0
        }
        score += lineBonus

        val columnHeights = IntArray(PlayerState.BOARD_COLS)
        var totalHeight = 0
        var holes = 0

        for (c in 0 until PlayerState.BOARD_COLS) {
            var foundBlock = false
            for (r in 0 until PlayerState.BOARD_ROWS) {
                if (board[r][c] != null) {
                    if (!foundBlock) {
                        columnHeights[c] = PlayerState.BOARD_ROWS - r
                        totalHeight += columnHeights[c]
                        foundBlock = true
                    }
                } else {
                    if (foundBlock) {
                        holes++
                    }
                }
            }
        }

        var bumpiness = 0
        for (c in 0 until PlayerState.BOARD_COLS - 1) {
            bumpiness += abs(columnHeights[c] - columnHeights[c + 1])
        }

        val maxHeight = columnHeights.maxOrNull() ?: 0

        val heightPenaltyWeight = if (difficulty == CpuDifficulty.HARD) 0.8 else 0.5
        val holePenaltyWeight = if (difficulty == CpuDifficulty.EASY) 4.0 else 14.0

        score -= totalHeight * heightPenaltyWeight
        score -= holes * holePenaltyWeight
        score -= bumpiness * 0.35
        score -= (maxHeight * maxHeight) * 0.15

        if (pieceType == PieceType.MONOMINO || pieceType.blockCount <= 2) {
            score += placedPiece.y * 2.0
        }

        return score
    }
}
