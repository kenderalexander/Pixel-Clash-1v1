package com.example.engine

import com.example.model.Cell
import com.example.model.FallingGarbagePiece
import com.example.model.PieceType
import com.example.model.PlayerState
import com.example.model.Tetromino
import kotlin.random.Random

object TetrisEngine {

    private var nextBlockId = 1L

    fun isValidPosition(
        board: List<List<Cell?>>,
        piece: Tetromino
    ): Boolean {
        val coords = piece.getOccupiedCoordinates()
        for ((cx, cy) in coords) {
            // Check wall boundaries
            if (cx < 0 || cx >= PlayerState.BOARD_COLS) return false
            if (cy >= PlayerState.BOARD_ROWS) return false
            // Can be above row 0 during spawn, but if in board, check if cell already occupied
            if (cy >= 0) {
                if (board[cy][cx] != null) return false
            }
        }
        return true
    }

    fun tryMove(
        board: List<List<Cell?>>,
        piece: Tetromino,
        dx: Int,
        dy: Int
    ): Tetromino? {
        val moved = piece.move(dx, dy)
        return if (isValidPosition(board, moved)) moved else null
    }

    fun tryRotate(
        board: List<List<Cell?>>,
        piece: Tetromino
    ): Tetromino? {
        val rotated = piece.rotateClockwise()
        if (isValidPosition(board, rotated)) return rotated

        // Wall kick offsets to try
        val kicks = listOf(
            Pair(-1, 0),
            Pair(1, 0),
            Pair(-2, 0),
            Pair(2, 0),
            Pair(0, -1),
            Pair(-1, -1),
            Pair(1, -1)
        )

        for ((kx, ky) in kicks) {
            val kicked = rotated.move(kx, ky)
            if (isValidPosition(board, kicked)) {
                return kicked
            }
        }

        return null
    }

    fun calculateGhost(
        board: List<List<Cell?>>,
        piece: Tetromino
    ): Tetromino {
        var current = piece
        while (true) {
            val next = current.move(0, 1)
            if (isValidPosition(board, next)) {
                current = next
            } else {
                break
            }
        }
        return current
    }

    /**
     * Standard Tetris line clearing:
     * Identifies completely filled rows (10/10 cells), removes them, and drops upper rows intact as solid units.
     * Preserves rigid piece structures and holes underneath.
     */
    fun processStandardLineClears(board: List<List<Cell?>>): Pair<List<List<Cell?>>, List<Int>> {
        val mutableBoard = board.map { it.toMutableList() }.toMutableList()
        val clearedIndices = mutableListOf<Int>()

        for (r in 0 until PlayerState.BOARD_ROWS) {
            if (mutableBoard[r].all { it != null }) {
                clearedIndices.add(r)
            }
        }

        if (clearedIndices.isEmpty()) {
            return Pair(board, emptyList())
        }

        val remainingRows = mutableBoard.filterIndexed { index, _ -> index !in clearedIndices }
        val newEmptyRows = List(clearedIndices.size) {
            MutableList<Cell?>(PlayerState.BOARD_COLS) { null }
        }

        val finalBoard = (newEmptyRows + remainingRows).map { it.toList() }
        return Pair(finalBoard, clearedIndices)
    }

    data class LockResult(
        val newBoard: List<List<Cell?>>,
        val boardWithPiece: List<List<Cell?>>,
        val clearedRows: List<Int>,
        val isTopOut: Boolean
    )

    fun lockPiece(
        board: List<List<Cell?>>,
        piece: Tetromino
    ): LockResult {
        val mutableBoard = board.map { it.toMutableList() }.toMutableList()
        val coords = piece.getOccupiedCoordinates()

        var toppedOut = false
        val cellToPlace = Cell.fromPiece(piece.type)

        for ((cx, cy) in coords) {
            if (cy < 0) {
                toppedOut = true
            } else if (cy < PlayerState.BOARD_ROWS && cx in 0 until PlayerState.BOARD_COLS) {
                mutableBoard[cy][cx] = cellToPlace
            }
        }

        val boardWithPiece = mutableBoard.map { it.toList() }
        val (finalBoard, clearedRows) = processStandardLineClears(boardWithPiece)

        return LockResult(finalBoard, boardWithPiece, clearedRows, toppedOut)
    }

    /**
     * Calculates attack blocks sent to opponent:
     * When 1 or more horizontal lines are eliminated,
     * calculates 75% of the total eliminated squares (10 squares per line)
     * and applies combo multipliers for consecutive clears (e.g. Combo x2 -> 1.5x attack).
     */
    fun calculateAttackBlocks(linesCleared: Int, combo: Int = 0): Int {
        if (linesCleared <= 0) return 0
        val totalSquaresEliminated = linesCleared * PlayerState.BOARD_COLS
        val baseAttack = (totalSquaresEliminated * 0.75f).toInt()

        val comboMultiplier = when {
            combo >= 4 -> 2.5f
            combo == 3 -> 2.0f
            combo == 2 -> 1.5f
            else -> 1.0f
        }

        return (baseAttack * comboMultiplier).toInt()
    }

    /**
     * Groups total attack squares into rigid piece sizes using random probability distribution:
     * - 65% chance for 1x1 (Monominos isolados)
     * - 35% chance for 1x2 (Dominos horizontais)
     * Removes 1x3 or larger pieces from attack waves.
     */
    fun partitionAttackIntoPieces(totalSquares: Int): List<Int> {
        if (totalSquares <= 0) return emptyList()
        var remaining = totalSquares
        val pieceSizes = mutableListOf<Int>()

        while (remaining > 0) {
            val roll = Random.nextInt(100) // 0..99
            val desiredSize = if (roll < 65) 1 else 2 // 65% chance for 1x1, 35% chance for 1x2

            val actualSize = if (desiredSize <= remaining) desiredSize else remaining
            pieceSizes.add(actualSize)
            remaining -= actualSize
        }

        return pieceSizes
    }

    /**
     * Creates falling rigid garbage pieces (1x1, 1x2, 1x3) that enter from the top of the grid
     * in random columns immediately after line elimination and fall continuously as unified solid units.
     */
    fun createFallingGarbagePieceWave(
        board: List<List<Cell?>>,
        currentFalling: List<FallingGarbagePiece>,
        totalAttackBlocks: Int
    ): List<FallingGarbagePiece> {
        if (totalAttackBlocks <= 0) return emptyList()

        val pieceSizes = partitionAttackIntoPieces(totalAttackBlocks)
        val newPieces = mutableListOf<FallingGarbagePiece>()

        var index = 0
        for (size in pieceSizes) {
            val maxStartCol = (PlayerState.BOARD_COLS - size).coerceAtLeast(0)
            val startCol = Random.nextInt(maxStartCol + 1)

            val delayTicks = index * 2
            index++

            newPieces.add(
                FallingGarbagePiece(
                    id = nextBlockId++,
                    size = size,
                    startCol = startCol,
                    y = 0,
                    targetY = 19,
                    spawnDelayTicks = delayTicks
                )
            )
        }

        return newPieces
    }

    data class StepGarbagePiecesResult(
        val newBoard: List<List<Cell?>>,
        val remainingFalling: List<FallingGarbagePiece>,
        val isTopOut: Boolean
    )

    /**
     * Advances falling rigid garbage pieces (1x1, 1x2, 1x3, 1x4) continuously downwards as solid unified units.
     * Stops falling when ANY block of the piece touches the grid floor or an existing block directly below it.
     * Locks intact preserving holes underneath if the board below is uneven.
     */
    fun stepFallingGarbagePieces(
        board: List<List<Cell?>>,
        fallingList: List<FallingGarbagePiece>
    ): StepGarbagePiecesResult {
        if (fallingList.isEmpty()) {
            return StepGarbagePiecesResult(board, emptyList(), false)
        }

        val mutableBoard = board.map { it.toMutableList() }.toMutableList()
        val remaining = mutableListOf<FallingGarbagePiece>()
        var topOut = false
        var landedAny = false

        for (fp in fallingList) {
            if (fp.spawnDelayTicks > 0) {
                remaining.add(fp.copy(spawnDelayTicks = fp.spawnDelayTicks - 1))
            } else {
                val endCol = (fp.startCol + fp.size).coerceAtMost(PlayerState.BOARD_COLS)

                if (fp.y >= PlayerState.BOARD_ROWS) {
                    topOut = true
                    continue
                }

                val nextY = fp.y + 1
                var canMoveDown = true

                if (nextY >= PlayerState.BOARD_ROWS) {
                    canMoveDown = false // Touched floor boundary
                } else {
                    // Rigorous collision check under ALL blocks of the unified piece
                    for (c in fp.startCol until endCol) {
                        if (mutableBoard[nextY][c] != null) {
                            canMoveDown = false // Touched solid block underneath
                            break
                        }
                    }
                }

                if (canMoveDown) {
                    // Entire rigid piece drops down 1 row intact
                    remaining.add(fp.copy(y = nextY))
                } else {
                    // Entire rigid piece lands as a solid unit at row fp.y!
                    landedAny = true
                    if (fp.y < 0) {
                        topOut = true
                    } else {
                        for (c in fp.startCol until endCol) {
                            if (fp.y in 0 until PlayerState.BOARD_ROWS) {
                                mutableBoard[fp.y][c] = Cell.GARBAGE
                            }
                        }
                    }
                }
            }
        }

        // Check for completed rows when rigid garbage pieces land
        var finalBoard = mutableBoard.map { it.toList() }
        if (landedAny) {
            val (clearedBoard, _) = processStandardLineClears(finalBoard)
            finalBoard = clearedBoard
        }

        return StepGarbagePiecesResult(finalBoard, remaining, topOut)
    }
}
