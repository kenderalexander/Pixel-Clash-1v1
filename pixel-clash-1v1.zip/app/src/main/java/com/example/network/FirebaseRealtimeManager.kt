package com.example.network

import com.example.model.Cell
import com.example.model.PieceType
import com.example.model.PlayerState
import com.example.model.PlayerInventory
import com.example.model.ButtonPos
import com.example.model.ControlSettings
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class OnlineRoomState(
    val code: String = "",
    val estado: String = "aguardando_jogadores", // "aguardando_jogadores", "em_jogo", "finalizado"
    val p1Id: String = "",
    val p2Id: String = "",
    val p1Score: Int = 0,
    val p2Score: Int = 0,
    val p1Lines: Int = 0,
    val p2Lines: Int = 0,
    val p1GameOver: Boolean = false,
    val p2GameOver: Boolean = false,
    val p1BoardStr: String = "",
    val p2BoardStr: String = "",
    val attackForP1: Int = 0,
    val attackForP2: Int = 0,
    val vencedor: String = ""
)

data class LeaderboardEntry(
    val id: String = "",
    val nickname: String = "",
    val pontuacao_maxima: Int = 0,
    val total_vitorias: Int = 0,
    val pl: Int = 0
)

class FirebaseRealtimeManager {

    private val databaseUrl = "https://pixelclash1v1-default-rtdb.firebaseio.com"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private var dbRef: DatabaseReference? = null
    private var activeRoomListener: ValueEventListener? = null
    private var activeRoomRef: DatabaseReference? = null

    init {
        try {
            val db = FirebaseDatabase.getInstance(databaseUrl)
            dbRef = db.getReference("partidas")
        } catch (_: Exception) {
            dbRef = null
        }
    }

    fun generateRoomCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..4).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    }

    fun createRoom(
        roomCode: String,
        playerId: String,
        onSuccess: (OnlineRoomState) -> Unit,
        onError: (String) -> Unit
    ) {
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val initialState = OnlineRoomState(
                    code = roomCode,
                    estado = "aguardando_jogadores",
                    p1Id = playerId
                )

                // Try Firebase SDK first
                dbRef?.child(roomCode)?.setValue(
                    mapOf(
                        "code" to roomCode,
                        "estado" to "aguardando_jogadores",
                        "p1Id" to playerId,
                        "p2Id" to "",
                        "p1Score" to 0,
                        "p2Score" to 0,
                        "p1Lines" to 0,
                        "p2Lines" to 0,
                        "p1GameOver" to false,
                        "p2GameOver" to false,
                        "p1BoardStr" to "",
                        "p2BoardStr" to "",
                        "attackForP1" to 0,
                        "attackForP2" to 0,
                        "vencedor" to ""
                    )
                )

                // REST API sync backup
                val json = JSONObject().apply {
                    put("code", roomCode)
                    put("estado", "aguardando_jogadores")
                    put("p1Id", playerId)
                    put("p2Id", "")
                    put("p1Score", 0)
                    put("p2Score", 0)
                    put("p1Lines", 0)
                    put("p2Lines", 0)
                    put("p1GameOver", false)
                    put("p2GameOver", false)
                    put("p1BoardStr", "")
                    put("p2BoardStr", "")
                    put("attackForP1", 0)
                    put("attackForP2", 0)
                    put("vencedor", "")
                }

                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url("$databaseUrl/partidas/$roomCode.json")
                    .put(body)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        onSuccess(initialState)
                    } else {
                        onSuccess(initialState)
                    }
                }
            } catch (e: Exception) {
                // Fallback to local initial state
                onSuccess(OnlineRoomState(code = roomCode, estado = "aguardando_jogadores", p1Id = playerId))
            }
        }
    }

    fun findQuickMatch(
        playerId: String,
        onFound: (roomCode: String) -> Unit,
        onNotFound: () -> Unit
    ) {
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/partidas.json"
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string()
                    if (!bodyStr.isNullOrEmpty() && bodyStr != "null") {
                        val json = JSONObject(bodyStr)
                        val keys = json.keys()
                        while (keys.hasNext()) {
                            val code = keys.next()
                            val roomObj = json.optJSONObject(code) ?: continue
                            val estado = roomObj.optString("estado", "")
                            val p1Id = roomObj.optString("p1Id", "")
                            val p2Id = roomObj.optString("p2Id", "")

                            if ((estado == "aguardando" || estado == "aguardando_jogadores") &&
                                p1Id != playerId &&
                                p2Id.isEmpty()
                            ) {
                                onFound(code)
                                return@launch
                            }
                        }
                    }
                    onNotFound()
                }
            } catch (_: Exception) {
                onNotFound()
            }
        }
    }

    fun joinRoom(
        roomCode: String,
        playerId: String,
        onSuccess: (OnlineRoomState) -> Unit,
        onError: (String) -> Unit
    ) {
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/partidas/$roomCode.json"
                val getRequest = Request.Builder().url(url).get().build()

                client.newCall(getRequest).execute().use { response ->
                    val bodyStr = response.body?.string()
                    if (bodyStr.isNullOrEmpty() || bodyStr == "null") {
                        onError("SALA NÃO ENCONTRADA ($roomCode)")
                        return@launch
                    }

                    val json = JSONObject(bodyStr)
                    val estado = json.optString("estado", "aguardando_jogadores")
                    val p1Id = json.optString("p1Id", "")

                    if (p1Id == playerId) {
                        // Rejoining as creator
                        onSuccess(
                            OnlineRoomState(
                                code = roomCode,
                                estado = estado,
                                p1Id = p1Id
                            )
                        )
                        return@launch
                    }

                    // Update room state to "em_jogo" with P2
                    json.put("p2Id", playerId)
                    json.put("estado", "em_jogo")

                    val updateBody = json.toString().toRequestBody("application/json".toMediaType())
                    val putRequest = Request.Builder().url(url).put(updateBody).build()
                    client.newCall(putRequest).execute().close()

                    dbRef?.child(roomCode)?.updateChildren(
                        mapOf(
                            "p2Id" to playerId,
                            "estado" to "em_jogo"
                        )
                    )

                    onSuccess(
                        OnlineRoomState(
                            code = roomCode,
                            estado = "em_jogo",
                            p1Id = p1Id,
                            p2Id = playerId
                        )
                    )
                }
            } catch (e: Exception) {
                onError("ERRO AO CONECTAR À SALA: ${e.message}")
            }
        }
    }

    fun deleteRoom(roomCode: String) {
        if (roomCode.isEmpty()) return
        dbRef?.child(roomCode)?.removeValue()
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val request = Request.Builder()
                    .url("$databaseUrl/partidas/$roomCode.json")
                    .delete()
                    .build()
                client.newCall(request).execute().close()
            } catch (_: Exception) {}
        }
    }

    fun listenToRoom(
        roomCode: String,
        onUpdate: (OnlineRoomState) -> Unit
    ) {
        stopRoomListener()

        dbRef?.child(roomCode)?.let { ref ->
            activeRoomRef = ref
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (!snapshot.exists()) return
                    val state = parseSnapshot(roomCode, snapshot)
                    onUpdate(state)
                }

                override fun onCancelled(error: DatabaseError) {
                    // Fallback
                }
            }
            activeRoomListener = listener
            ref.addValueEventListener(listener)
        }
    }

    fun stopRoomListener() {
        activeRoomListener?.let { l ->
            activeRoomRef?.removeEventListener(l)
        }
        activeRoomListener = null
        activeRoomRef = null
    }

    fun updatePlayerState(
        roomCode: String,
        isPlayer1: Boolean,
        board: List<List<Cell?>>,
        score: Int,
        lines: Int,
        isGameOver: Boolean
    ) {
        val boardStr = serializeBoard(board)
        val prefix = if (isPlayer1) "p1" else "p2"

        dbRef?.child(roomCode)?.updateChildren(
            mapOf(
                "${prefix}BoardStr" to boardStr,
                "${prefix}Score" to score,
                "${prefix}Lines" to lines,
                "${prefix}GameOver" to isGameOver
            )
        )

        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val json = JSONObject().apply {
                    put("${prefix}BoardStr", boardStr)
                    put("${prefix}Score", score)
                    put("${prefix}Lines", lines)
                    put("${prefix}GameOver", isGameOver)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url("$databaseUrl/partidas/$roomCode.json")
                    .patch(body)
                    .build()
                client.newCall(request).execute().close()
            } catch (_: Exception) {}
        }
    }

    fun sendAttackToOpponent(
        roomCode: String,
        isPlayer1: Boolean,
        attackBlocks: Int
    ) {
        if (attackBlocks <= 0) return
        val field = if (isPlayer1) "attackForP2" else "attackForP1"

        dbRef?.child(roomCode)?.child(field)?.get()?.addOnSuccessListener { snapshot ->
            val current = snapshot.getValue(Int::class.java) ?: 0
            dbRef?.child(roomCode)?.child(field)?.setValue(current + attackBlocks)
        }

        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val getReq = Request.Builder().url("$databaseUrl/partidas/$roomCode/$field.json").get().build()
                client.newCall(getReq).execute().use { resp ->
                    val str = resp.body?.string() ?: "0"
                    val current = str.toIntOrNull() ?: 0
                    val json = JSONObject().apply { put(field, current + attackBlocks) }
                    val body = json.toString().toRequestBody("application/json".toMediaType())
                    val patchReq = Request.Builder().url("$databaseUrl/partidas/$roomCode.json").patch(body).build()
                    client.newCall(patchReq).execute().close()
                }
            } catch (_: Exception) {}
        }
    }

    fun clearPendingAttacks(
        roomCode: String,
        isPlayer1: Boolean
    ) {
        val field = if (isPlayer1) "attackForP1" else "attackForP2"
        dbRef?.child(roomCode)?.child(field)?.setValue(0)

        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val json = JSONObject().apply { put(field, 0) }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val patchReq = Request.Builder().url("$databaseUrl/partidas/$roomCode.json").patch(body).build()
                client.newCall(patchReq).execute().close()
            } catch (_: Exception) {}
        }
    }

    fun fetchPlayerProfile(
        nickname: String,
        deviceId: String = "",
        pin: String = "",
        onPinRequired: () -> Unit = {},
        onSuccess: (nickname: String, pl: Int, inventory: PlayerInventory, totalVitorias: Int, level: Int, layout: ControlSettings, savedPin: String) -> Unit,
        onError: (String) -> Unit
    ) {
        val lowercaseKey = nickname.lowercase().trim()
        if (lowercaseKey.isEmpty()) {
            onError("Nome do jogador vazio")
            return
        }
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey.json"
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string()
                    if (bodyStr.isNullOrEmpty() || bodyStr == "null") {
                        // Create initial profile for a new player
                        val initialLayout = ControlSettings()
                        val initialInventory = PlayerInventory()
                        val json = JSONObject().apply {
                            put("id", lowercaseKey)
                            put("nickname", nickname)
                            put("pontuacao_maxima", 0)
                            put("total_vitorias", 0)
                            put("level", 1)
                            put("deviceId", deviceId)
                            put("pin", pin)
                            put("pl", 0)
                            put("inventory", JSONObject(mapOf(
                                "coins" to 0,
                                "boughtItems" to emptyList<String>(),
                                "equippedItems" to emptyMap<String, String>()
                            )))
                            put("scale", initialLayout.scale)
                            put("opacity", initialLayout.opacity)
                            put("buttonGap", initialLayout.buttonGap)
                            put("posLeftX", initialLayout.posLeft.x)
                            put("posLeftY", initialLayout.posLeft.y)
                            put("posRotateX", initialLayout.posRotate.x)
                            put("posRotateY", initialLayout.posRotate.y)
                            put("posRightX", initialLayout.posRight.x)
                            put("posRightY", initialLayout.posRight.y)
                            put("posSoftDropX", initialLayout.posSoftDrop.x)
                            put("posSoftDropY", initialLayout.posSoftDrop.y)
                            put("posHardDropX", initialLayout.posHardDrop.x)
                            put("posHardDropY", initialLayout.posHardDrop.y)
                        }
                        val body = json.toString().toRequestBody("application/json".toMediaType())
                        val putRequest = Request.Builder().url(url).put(body).build()
                        client.newCall(putRequest).execute().close()

                        try {
                            val db = FirebaseDatabase.getInstance(databaseUrl)
                            db.getReference("jogadores").child(lowercaseKey).setValue(
                                mapOf(
                                    "id" to lowercaseKey,
                                    "nickname" to nickname,
                                    "pontuacao_maxima" to 0,
                                    "total_vitorias" to 0,
                                    "level" to 1,
                                    "deviceId" to deviceId,
                                    "pin" to pin,
                                    "pl" to 0,
                                    "inventory" to mapOf(
                                        "coins" to 0,
                                        "boughtItems" to emptyList<String>(),
                                        "equippedItems" to emptyMap<String, String>()
                                    ),
                                    "scale" to initialLayout.scale,
                                    "opacity" to initialLayout.opacity,
                                    "buttonGap" to initialLayout.buttonGap,
                                    "posLeftX" to initialLayout.posLeft.x,
                                    "posLeftY" to initialLayout.posLeft.y,
                                    "posRotateX" to initialLayout.posRotate.x,
                                    "posRotateY" to initialLayout.posRotate.y,
                                    "posRightX" to initialLayout.posRight.x,
                                    "posRightY" to initialLayout.posRight.y,
                                    "posSoftDropX" to initialLayout.posSoftDrop.x,
                                    "posSoftDropY" to initialLayout.posSoftDrop.y,
                                    "posHardDropX" to initialLayout.posHardDrop.x,
                                    "posHardDropY" to initialLayout.posHardDrop.y
                                )
                            )
                        } catch (_: Exception) {}

                        onSuccess(nickname, 0, initialInventory, 0, 1, initialLayout, pin)
                    } else {
                        val json = JSONObject(bodyStr)
                        val fetchedNickname = json.optString("nickname", nickname)
                        val savedDeviceId = json.optString("deviceId", "")
                        val savedPin = json.optString("pin", "")
                        val pontuacaoMaxima = json.optInt("pontuacao_maxima", 0)
                        val totalVitorias = json.optInt("total_vitorias", 0)
                        val level = json.optInt("level", 1)
                        val pl = json.optInt("pl", 0)

                        val inventoryObj = json.optJSONObject("inventory")
                        val inventory = if (inventoryObj != null) {
                            val boughtItemsList = mutableListOf<String>()
                            val boughtItemsJson = inventoryObj.optJSONArray("boughtItems")
                            if (boughtItemsJson != null) {
                                for (i in 0 until boughtItemsJson.length()) {
                                    boughtItemsList.add(boughtItemsJson.getString(i))
                                }
                            }
                            val equippedItemsMap = mutableMapOf<String, String>()
                            val equippedItemsJson = inventoryObj.optJSONObject("equippedItems")
                            if (equippedItemsJson != null) {
                                val keys = equippedItemsJson.keys()
                                while (keys.hasNext()) {
                                    val key = keys.next()
                                    equippedItemsMap[key] = equippedItemsJson.getString(key)
                                }
                            }
                            PlayerInventory(
                                coins = inventoryObj.optInt("coins", 0),
                                boughtItems = boughtItemsList,
                                equippedItems = equippedItemsMap
                            )
                        } else {
                            PlayerInventory(coins = json.optInt("coins", 0))
                        }

                        val layout = ControlSettings(
                            scale = json.optDouble("scale", 1.0).toFloat(),
                            opacity = json.optDouble("opacity", 1.0).toFloat(),
                            buttonGap = json.optDouble("buttonGap", 8.0).toFloat(),
                            posLeft = ButtonPos(json.optDouble("posLeftX", 0.0).toFloat(), json.optDouble("posLeftY", 0.0).toFloat()),
                            posRotate = ButtonPos(json.optDouble("posRotateX", 0.0).toFloat(), json.optDouble("posRotateY", 0.0).toFloat()),
                            posRight = ButtonPos(json.optDouble("posRightX", 0.0).toFloat(), json.optDouble("posRightY", 0.0).toFloat()),
                            posSoftDrop = ButtonPos(json.optDouble("posSoftDropX", 0.0).toFloat(), json.optDouble("posSoftDropY", 0.0).toFloat()),
                            posHardDrop = ButtonPos(json.optDouble("posHardDropX", 0.0).toFloat(), json.optDouble("posHardDropY", 0.0).toFloat())
                        )

                        // Authenticate PIN
                        if (savedPin.isNotEmpty()) {
                            if (pin == savedPin) {
                                // Correct PIN, allow access from any device and associate current deviceId
                                if (savedDeviceId != deviceId && deviceId.isNotEmpty()) {
                                    updateDeviceIdAndPin(lowercaseKey, deviceId, savedPin)
                                }
                                onSuccess(fetchedNickname, pl, inventory, totalVitorias, level, layout, savedPin)
                            } else {
                                if (pin.isEmpty()) {
                                    onPinRequired()
                                } else {
                                    onError("PIN incorreto. Tente novamente.")
                                }
                            }
                        } else {
                            // If there is no PIN saved on the account yet, set it now
                            if (pin.isNotEmpty()) {
                                updateDeviceIdAndPin(lowercaseKey, deviceId, pin)
                            }
                            onSuccess(fetchedNickname, pl, inventory, totalVitorias, level, layout, pin)
                        }
                    }
                }
            } catch (e: Exception) {
                onError(e.message ?: "Erro ao carregar perfil")
            }
        }
    }

    fun checkNicknameExists(
        nickname: String,
        onResult: (exists: Boolean) -> Unit
    ) {
        val lowercaseKey = nickname.lowercase().trim()
        if (lowercaseKey.isEmpty()) {
            onResult(false)
            return
        }
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey.json"
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string()
                    val exists = !bodyStr.isNullOrEmpty() && bodyStr != "null"
                    onResult(exists)
                }
            } catch (_: Exception) {
                onResult(false)
            }
        }
    }

    fun updateDeviceIdAndPin(lowercaseKey: String, deviceId: String, pin: String) {
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey.json"
                val json = JSONObject().apply {
                    if (deviceId.isNotEmpty()) put("deviceId", deviceId)
                    put("pin", pin)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val patchRequest = Request.Builder().url(url).patch(body).build()
                client.newCall(patchRequest).execute().close()

                try {
                    val db = FirebaseDatabase.getInstance(databaseUrl)
                    val updates = mutableMapOf<String, Any>("pin" to pin)
                    if (deviceId.isNotEmpty()) updates["deviceId"] = deviceId
                    db.getReference("jogadores").child(lowercaseKey).updateChildren(updates)
                } catch (_: Exception) {}
            } catch (_: Exception) {}
        }
    }

    fun updatePlayerPoints(nickname: String, pl: Int) {
        val lowercaseKey = nickname.lowercase().trim()
        if (lowercaseKey.isEmpty()) return
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val db = FirebaseDatabase.getInstance(databaseUrl)
                db.getReference("jogadores").child(lowercaseKey).child("pl").setValue(pl)
            } catch (_: Exception) {}
        }
    }

    fun savePlayerLayout(nickname: String, settings: ControlSettings) {
        val lowercaseKey = nickname.lowercase().trim()
        if (lowercaseKey.isEmpty()) return
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey.json"
                val json = JSONObject().apply {
                    put("scale", settings.scale)
                    put("opacity", settings.opacity)
                    put("buttonGap", settings.buttonGap)
                    put("posLeftX", settings.posLeft.x)
                    put("posLeftY", settings.posLeft.y)
                    put("posRotateX", settings.posRotate.x)
                    put("posRotateY", settings.posRotate.y)
                    put("posRightX", settings.posRight.x)
                    put("posRightY", settings.posRight.y)
                    put("posSoftDropX", settings.posSoftDrop.x)
                    put("posSoftDropY", settings.posSoftDrop.y)
                    put("posHardDropX", settings.posHardDrop.x)
                    put("posHardDropY", settings.posHardDrop.y)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val patchRequest = Request.Builder().url(url).patch(body).build()
                client.newCall(patchRequest).execute().close()

                try {
                    val db = FirebaseDatabase.getInstance(databaseUrl)
                    db.getReference("jogadores").child(lowercaseKey).updateChildren(
                        mapOf(
                            "scale" to settings.scale,
                            "opacity" to settings.opacity,
                            "buttonGap" to settings.buttonGap,
                            "posLeftX" to settings.posLeft.x,
                            "posLeftY" to settings.posLeft.y,
                            "posRotateX" to settings.posRotate.x,
                            "posRotateY" to settings.posRotate.y,
                            "posRightX" to settings.posRight.x,
                            "posRightY" to settings.posRight.y,
                            "posSoftDropX" to settings.posSoftDrop.x,
                            "posSoftDropY" to settings.posSoftDrop.y,
                            "posHardDropX" to settings.posHardDrop.x,
                            "posHardDropY" to settings.posHardDrop.y
                        )
                    )
                } catch (_: Exception) {}
            } catch (_: Exception) {}
        }
    }

    fun updatePlayerProgression(
        nickname: String,
        pl: Int,
        coins: Int,
        inventory: PlayerInventory
    ) {
        val lowercaseKey = nickname.lowercase().trim()
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey.json"
                val json = JSONObject().apply {
                    put("pl", pl)
                    put("coins", coins)
                    put("inventory", JSONObject(mapOf(
                        "coins" to inventory.coins,
                        "boughtItems" to inventory.boughtItems,
                        "equippedItems" to inventory.equippedItems
                    )))
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val patchRequest = Request.Builder().url(url).patch(body).build()
                client.newCall(patchRequest).execute().close()
            } catch (_: Exception) {}
        }
    }

    fun updateDailyMission(
        nickname: String,
        missionId: Int,
        isCompleted: Boolean,
        lastResetTimestamp: Long
    ) {
        val lowercaseKey = nickname.lowercase().trim()
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey/dailyMissions/$missionId.json"
                val json = JSONObject().apply {
                    put("completed", isCompleted)
                    put("lastReset", lastResetTimestamp)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val patchRequest = Request.Builder().url(url).patch(body).build()
                client.newCall(patchRequest).execute().close()
            } catch (_: Exception) {}
        }
    }


    fun updateHeadToHead(
        playerNickname: String,
        opponentNickname: String,
        isWin: Boolean
    ) {
        val p1 = playerNickname.lowercase().trim()
        val p2 = opponentNickname.lowercase().trim()
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                // Simplified H2H: store count under p1's profile
                val url = "$databaseUrl/jogadores/$p1/headToHead/$p2.json"
                val getReq = Request.Builder().url(url).get().build()
                client.newCall(getReq).execute().use { response ->
                    val bodyStr = response.body?.string()
                    val current = if (!bodyStr.isNullOrEmpty() && bodyStr != "null") bodyStr.toInt() else 0
                    val newCount = if (isWin) current + 1 else current
                    val body = newCount.toString().toRequestBody("application/json".toMediaType())
                    val putReq = Request.Builder().url(url).put(body).build()
                    client.newCall(putReq).execute().close()
                }
            } catch (_: Exception) {}
        }
    }

    fun submitRankingProgress(
        nickname: String,
        score: Int,
        level: Int,
        isVictory: Boolean,
        onSuccess: (pontuacaoMaxima: Int, totalVitorias: Int) -> Unit = { _, _ -> },
        onError: (String) -> Unit = {}
    ) {
        val lowercaseKey = nickname.lowercase().trim()
        if (lowercaseKey.isEmpty()) {
            onError("Nome do jogador vazio")
            return
        }
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores/$lowercaseKey.json"
                val getRequest = Request.Builder().url(url).get().build()
                var currentVitorias = 0
                var currentPontuacao = 0
                var currentLevel = 1
                client.newCall(getRequest).execute().use { response ->
                    val bodyStr = response.body?.string()
                    if (!bodyStr.isNullOrEmpty() && bodyStr != "null") {
                        val json = JSONObject(bodyStr)
                        currentVitorias = json.optInt("total_vitorias", 0)
                        currentPontuacao = json.optInt("pontuacao_maxima", 0)
                        currentLevel = json.optInt("level", 1)
                    }
                }

                val newVitorias = if (isVictory) currentVitorias + 1 else currentVitorias
                val newPontuacao = if (score > currentPontuacao) score else currentPontuacao
                val newLevel = if (level > currentLevel) level else currentLevel

                val json = JSONObject().apply {
                    put("nickname", nickname)
                    put("pontuacao_maxima", newPontuacao)
                    put("total_vitorias", newVitorias)
                    put("level", newLevel)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val patchRequest = Request.Builder().url(url).patch(body).build()
                client.newCall(patchRequest).execute().close()

                try {
                    val db = FirebaseDatabase.getInstance(databaseUrl)
                    db.getReference("jogadores").child(lowercaseKey).updateChildren(
                        mapOf(
                            "nickname" to nickname,
                            "pontuacao_maxima" to newPontuacao,
                            "total_vitorias" to newVitorias,
                            "level" to newLevel
                        )
                    )
                } catch (_: Exception) {}

                onSuccess(newPontuacao, newVitorias)
            } catch (e: Exception) {
                onError(e.message ?: "Erro desconhecido")
            }
        }
    }

    fun fetchLeaderboard(
        onSuccess: (List<LeaderboardEntry>) -> Unit,
        onError: (String) -> Unit
    ) {
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val url = "$databaseUrl/jogadores.json"
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string()
                    val list = mutableListOf<LeaderboardEntry>()
                    if (!bodyStr.isNullOrEmpty() && bodyStr != "null") {
                        val json = JSONObject(bodyStr)
                        val keys = json.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val obj = json.optJSONObject(key)
                            if (obj != null) {
                                val id = obj.optString("id", key)
                                val nickname = obj.optString("nickname", "Jugador Sin Nombre")
                                val pontuacao_maxima = obj.optInt("pontuacao_maxima", 0)
                                val total_vitorias = obj.optInt("total_vitorias", 0)
                                val pl = obj.optInt("pl", 0)
                                list.add(LeaderboardEntry(id, nickname, pontuacao_maxima, total_vitorias, pl))
                            }
                        }
                    }
                    val sorted = list.sortedByDescending { it.pl }.take(50)
                    onSuccess(sorted)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Erro ao buscar ranking")
            }
        }
    }

    fun setWinner(
        roomCode: String,
        winnerId: String
    ) {
        dbRef?.child(roomCode)?.updateChildren(
            mapOf(
                "vencedor" to winnerId,
                "estado" to "finalizado"
            )
        )
    }

    private fun parseSnapshot(roomCode: String, snapshot: DataSnapshot): OnlineRoomState {
        return OnlineRoomState(
            code = roomCode,
            estado = snapshot.child("estado").getValue(String::class.java) ?: "aguardando_jogadores",
            p1Id = snapshot.child("p1Id").getValue(String::class.java) ?: "",
            p2Id = snapshot.child("p2Id").getValue(String::class.java) ?: "",
            p1Score = snapshot.child("p1Score").getValue(Int::class.java) ?: 0,
            p2Score = snapshot.child("p2Score").getValue(Int::class.java) ?: 0,
            p1Lines = snapshot.child("p1Lines").getValue(Int::class.java) ?: 0,
            p2Lines = snapshot.child("p2Lines").getValue(Int::class.java) ?: 0,
            p1GameOver = snapshot.child("p1GameOver").getValue(Boolean::class.java) ?: false,
            p2GameOver = snapshot.child("p2GameOver").getValue(Boolean::class.java) ?: false,
            p1BoardStr = snapshot.child("p1BoardStr").getValue(String::class.java) ?: "",
            p2BoardStr = snapshot.child("p2BoardStr").getValue(String::class.java) ?: "",
            attackForP1 = snapshot.child("attackForP1").getValue(Int::class.java) ?: 0,
            attackForP2 = snapshot.child("attackForP2").getValue(Int::class.java) ?: 0,
            vencedor = snapshot.child("vencedor").getValue(String::class.java) ?: ""
        )
    }

    fun serializeBoard(board: List<List<Cell?>>): String {
        val sb = StringBuilder()
        for (r in board) {
            for (c in r) {
                if (c == null) {
                    sb.append('.')
                } else if (c.isGarbage) {
                    sb.append('G')
                } else {
                    sb.append('X')
                }
            }
        }
        return sb.toString()
    }

    fun deserializeBoard(str: String): List<List<Cell?>> {
        val board = MutableList(PlayerState.BOARD_ROWS) { MutableList<Cell?>(PlayerState.BOARD_COLS) { null } }
        if (str.length < PlayerState.BOARD_ROWS * PlayerState.BOARD_COLS) {
            return board.map { it.toList() }
        }

        var idx = 0
        for (r in 0 until PlayerState.BOARD_ROWS) {
            for (c in 0 until PlayerState.BOARD_COLS) {
                if (idx < str.length) {
                    val ch = str[idx++]
                    if (ch == 'G') {
                        board[r][c] = Cell.GARBAGE
                    } else if (ch == 'X') {
                        board[r][c] = Cell.fromPiece(PieceType.LINE_4)
                    }
                }
            }
        }
        return board.map { it.toList() }
    }
}
