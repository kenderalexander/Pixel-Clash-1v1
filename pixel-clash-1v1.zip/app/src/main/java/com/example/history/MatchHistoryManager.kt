package com.example.history

import android.content.Context
import com.example.model.AggregatedStats
import com.example.model.MatchRecord
import org.json.JSONArray
import org.json.JSONObject

class MatchHistoryManager(context: Context) {

    private val prefs = context.getSharedPreferences("pixel_clash_match_history", Context.MODE_PRIVATE)

    fun getHistory(): List<MatchRecord> {
        val jsonStr = prefs.getString("history_json", "[]") ?: "[]"
        val list = mutableListOf<MatchRecord>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                list.add(
                    MatchRecord(
                        id = obj.optString("id", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        gameMode = obj.optString("gameMode", ""),
                        isVictory = obj.optBoolean("isVictory", false),
                        linesCleared = obj.optInt("linesCleared", 0),
                        attacksSent = obj.optInt("attacksSent", 0),
                        durationSeconds = obj.optLong("durationSeconds", 0L),
                        score = obj.optInt("score", 0),
                        maxCombo = obj.optInt("maxCombo", 0)
                    )
                )
            }
        } catch (_: Exception) {}
        return list.sortedByDescending { it.timestamp }
    }

    fun saveMatch(record: MatchRecord) {
        val current = getHistory().toMutableList()
        current.add(0, record)

        // Keep last 50 matches
        val trimmed = current.take(50)

        val jsonArray = JSONArray()
        for (item in trimmed) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("gameMode", item.gameMode)
                put("isVictory", item.isVictory)
                put("linesCleared", item.linesCleared)
                put("attacksSent", item.attacksSent)
                put("durationSeconds", item.durationSeconds)
                put("score", item.score)
                put("maxCombo", item.maxCombo)
            }
            jsonArray.put(obj)
        }

        prefs.edit().putString("history_json", jsonArray.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().remove("history_json").apply()
    }

    fun getAggregatedStats(): AggregatedStats {
        val history = getHistory()
        if (history.isEmpty()) return AggregatedStats()

        val totalMatches = history.size
        val totalWins = history.count { it.isVictory }
        val totalLosses = totalMatches - totalWins
        val winRate = if (totalMatches > 0) ((totalWins.toFloat() / totalMatches) * 100).toInt() else 0
        val totalLines = history.sumOf { it.linesCleared }
        val totalAttacks = history.sumOf { it.attacksSent }
        val totalDuration = history.sumOf { it.durationSeconds }
        val highScore = history.maxOfOrNull { it.score } ?: 0

        return AggregatedStats(
            totalMatches = totalMatches,
            totalWins = totalWins,
            totalLosses = totalLosses,
            winRatePercent = winRate,
            totalLinesCleared = totalLines,
            totalAttacksSent = totalAttacks,
            totalPlayTimeSeconds = totalDuration,
            highScore = highScore
        )
    }
}
