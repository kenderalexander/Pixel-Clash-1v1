package com.example.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.model.Cell

object PixelBlockDrawer {

    /**
     * Draws an authentic retro pixel arcade block with 3D bevels and core fill
     */
    fun drawPixelBlock(
        drawScope: DrawScope,
        topLeft: Offset,
        blockSize: Float,
        cell: Cell,
        alpha: Float = 1.0f,
        skinId: String = "neon"
    ) {
        val bevel = blockSize * 0.16f
        var color = cell.color.copy(alpha = cell.color.alpha * alpha)
        var highlight = cell.highlightColor.copy(alpha = cell.highlightColor.alpha * alpha)
        var shadow = cell.shadowColor.copy(alpha = cell.shadowColor.alpha * alpha)

        // Apply skin modifications
        when (skinId) {
            "gb" -> {
                // Game Boy Classic: Shades of Green/Mint
                color = Color(0xFF8BAC0F).copy(alpha = alpha)
                highlight = Color(0xFF9BBC0F).copy(alpha = alpha)
                shadow = Color(0xFF306230).copy(alpha = alpha)
            }
            "cyber" -> {
                // Cyberpunk: High contrast purple and yellow
                color = if (cell.isGarbage) Color(0xFF311B92) else Color(0xFF7C4DFF).copy(alpha = alpha)
                highlight = Color(0xFFFFFF00).copy(alpha = alpha)
                shadow = Color(0xFF212121).copy(alpha = alpha)
            }
            "fireice" -> {
                // Fire & Ice: Gradient feel
                color = if (cell.color.red > cell.color.blue) Color(0xFFFF5722) else Color(0xFF03A9F4)
                highlight = Color.White.copy(alpha = 0.8f * alpha)
                shadow = Color.Black.copy(alpha = 0.5f * alpha)
            }
            "gold" -> {
                // Pure Gold
                color = Color(0xFFFFD600).copy(alpha = alpha)
                highlight = Color(0xFFFFF176).copy(alpha = alpha)
                shadow = Color(0xFFF57F17).copy(alpha = alpha)
            }
        }

        // Base fill
        drawScope.drawRect(
            color = color,
            topLeft = topLeft,
            size = Size(blockSize, blockSize)
        )

        // Top highlight
        drawScope.drawRect(
            color = highlight,
            topLeft = topLeft,
            size = Size(blockSize, bevel)
        )

        // Left highlight
        drawScope.drawRect(
            color = highlight,
            topLeft = topLeft,
            size = Size(bevel, blockSize)
        )

        // Bottom shadow
        drawScope.drawRect(
            color = shadow,
            topLeft = Offset(topLeft.x, topLeft.y + blockSize - bevel),
            size = Size(blockSize, bevel)
        )

        // Right shadow
        drawScope.drawRect(
            color = shadow,
            topLeft = Offset(topLeft.x + blockSize - bevel, topLeft.y),
            size = Size(bevel, blockSize)
        )

        // Inner pixel dot highlight (classic retro 90s aesthetic)
        val innerMargin = bevel * 1.5f
        val innerSize = blockSize * 0.16f
        drawScope.drawRect(
            color = Color.White.copy(alpha = 0.55f * alpha),
            topLeft = Offset(topLeft.x + innerMargin, topLeft.y + innerMargin),
            size = Size(innerSize, innerSize)
        )

        // Special texture for garbage blocks: metallic industrial cross/rivet pattern
        if (cell.isGarbage) {
            val center = Offset(topLeft.x + blockSize / 2f, topLeft.y + blockSize / 2f)
            val rivetSize = blockSize * 0.14f
            drawScope.drawRect(
                color = Color.Black.copy(alpha = 0.5f * alpha),
                topLeft = Offset(center.x - rivetSize / 2f, center.y - rivetSize / 2f),
                size = Size(rivetSize, rivetSize)
            )
        }

        // Dark outer border line for crisp pixel definition
        drawScope.drawRect(
            color = Color(0x77000000),
            topLeft = topLeft,
            size = Size(blockSize, blockSize),
            style = Stroke(width = 1f)
        )
    }

    /**
     * Draws a ghost block outline
     */
    fun drawGhostBlock(
        drawScope: DrawScope,
        topLeft: Offset,
        blockSize: Float,
        color: Color
    ) {
        val strokeWidth = 2.5f
        drawScope.drawRect(
            color = color.copy(alpha = 0.22f),
            topLeft = topLeft,
            size = Size(blockSize, blockSize)
        )
        drawScope.drawRect(
            color = color.copy(alpha = 0.65f),
            topLeft = topLeft,
            size = Size(blockSize, blockSize),
            style = Stroke(width = strokeWidth)
        )
    }
}
