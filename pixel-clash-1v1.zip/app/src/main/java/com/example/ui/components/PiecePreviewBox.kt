package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Cell
import com.example.model.PieceType

@Composable
fun PiecePreviewBox(
    title: String,
    pieceType: PieceType?,
    tag: String,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .testTag(tag)
            .border(1.5.dp, Color(0xFF2E3352), RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF101322))
            .padding(4.dp)
    ) {
        Text(
            text = title,
            color = Color(0xFF8C95B5),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Box(
            modifier = Modifier
                .size(46.dp)
                .background(Color(0xFF090A13), RoundedCornerShape(4.dp))
        ) {
            if (pieceType != null) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val shape = pieceType.getShape(0)
                    val rows = shape.size
                    val cols = shape[0].size
                    val blockSize = 11.dp.toPx()

                    val totalWidth = cols * blockSize
                    val totalHeight = rows * blockSize
                    val startX = (size.width - totalWidth) / 2f
                    val startY = (size.height - totalHeight) / 2f

                    val cell = Cell.fromPiece(pieceType)

                    for (r in 0 until rows) {
                        for (c in 0 until cols) {
                            if (shape[r][c] != 0) {
                                PixelBlockDrawer.drawPixelBlock(
                                    drawScope = this,
                                    topLeft = Offset(startX + c * blockSize, startY + r * blockSize),
                                    blockSize = blockSize,
                                    cell = cell
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
