package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.model.CpuDifficulty
import com.example.model.VersusGameState
import com.example.model.ShopItem
import com.example.model.Mission

@Composable
fun StartScreen(
    gameState: VersusGameState,
    onStartVsCpu: (CpuDifficulty) -> Unit,
    onOpenOnlineLobby: () -> Unit,
    onStartQuickMatch: () -> Unit,
    onCancelQuickMatch: () -> Unit,
    onCreateOnlineRoom: () -> Unit,
    onJoinOnlineRoom: (String) -> Unit,
    onConfirmOnlineMatch: () -> Unit,
    onCloseOnlineLobby: () -> Unit,
    onOpenControlsEditor: () -> Unit,
    onOpenHistory: () -> Unit,
    onToggleAudio: () -> Unit,
    getPlayerName: () -> String,
    getPlayerId: () -> String,
    hasSavedNickname: () -> Boolean,
    onSavePlayerName: (String, String) -> Unit,
    onFetchLeaderboard: (onSuccess: (List<com.example.network.LeaderboardEntry>) -> Unit, onError: (String) -> Unit) -> Unit,
    onConfirmPin: (String) -> Unit,
    onCancelPinPrompt: () -> Unit,
    onClearNicknameError: () -> Unit,
    getLocalPin: () -> String,
    onSaveLocalPin: (String) -> Unit,
    onCheckNicknameExists: (String, (Boolean) -> Unit) -> Unit,
    getPatentInfo: (Int) -> Pair<String, Color>,
    onBuyItem: (ShopItem) -> Unit,
    onEquipItem: (ShopItem) -> Unit,
    onClaimMission: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showRulesDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showCpuDifficultyDialog by remember { mutableStateOf(false) }
    var selectedDifficulty by remember { mutableStateOf(CpuDifficulty.MEDIUM) }
    var showLeaderboardDialog by remember { mutableStateOf(false) }
    var showShopDialog by remember { mutableStateOf(false) }
    var showMissionsDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var leaderboardList by remember { mutableStateOf<List<com.example.network.LeaderboardEntry>>(emptyList()) }
    var leaderboardLoading by remember { mutableStateOf(false) }
    var leaderboardError by remember { mutableStateOf("") }
    var currentNickname by remember { mutableStateOf(getPlayerName()) }
    val hasSession = hasSavedNickname()
    var showFirstTimeNicknameDialog by remember(hasSession) { mutableStateOf(!hasSession) }
    var firstTimeInputName by remember { mutableStateOf("") }
    var firstTimeInputPin by remember { mutableStateOf("") }
    var inputRoomCode by remember { mutableStateOf("") }
    var lobbyTabMode by remember { mutableStateOf("menu") } // "menu", "join"

    var activeAuthTab by remember { mutableStateOf("signup") } // "signup", "login"
    var localErrorMessage by remember { mutableStateOf("") }
    var isValidating by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    androidx.compose.runtime.LaunchedEffect(gameState.nicknameErrorMessage) {
        if (gameState.nicknameErrorMessage.isNotEmpty()) {
            isValidating = false
            localErrorMessage = gameState.nicknameErrorMessage
        }
    }

    androidx.compose.runtime.LaunchedEffect(gameState.wins, getPlayerName()) {
        val currentName = getPlayerName()
        if (currentName.isNotEmpty()) {
            if (showFirstTimeNicknameDialog) {
                showFirstTimeNicknameDialog = false
                showProfileDialog = true
                leaderboardLoading = true
                onFetchLeaderboard(
                    { list ->
                        leaderboardList = list
                        leaderboardLoading = false
                    },
                    { error ->
                        leaderboardLoading = false
                    }
                )
            }
            currentNickname = currentName
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0C0E1F),
                        Color(0xFF070812),
                        Color(0xFF040508)
                    )
                )
            )
            .testTag("start_menu_screen")
    ) {
        // Retro background pixel grid effect
        Canvas(modifier = Modifier.fillMaxSize()) {
            val gridStep = 40.dp.toPx()
            val w = size.width
            val h = size.height
            val gridColor = Color(0xFF13172E)

            var x = 0f
            while (x < w) {
                drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                x += gridStep
            }
            var y = 0f
            while (y < h) {
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                y += gridStep
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // New Top Header: Profile Info
            val (patentName, patentColor) = getPatentInfo(gameState.pl)
            Row(
                modifier = Modifier.fillMaxWidth().background(Color(0xFF101326), RoundedCornerShape(12.dp)).padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = currentNickname, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = patentName, color = patentColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Text(text = "🪙 ${gameState.coins}", color = Color(0xFFFFD600), fontSize = 16.sp, fontWeight = FontWeight.Black)
            }

            // Center Title Hero Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                // PIXEL CLASH title
                Text(
                    text = "PIXEL CLASH",
                    color = Color(0xFF00E5FF),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
                Box(
                    modifier = Modifier
                        .background(Color(0xFFFF1744), RoundedCornerShape(4.dp))
                        .padding(horizontal = 14.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "1 v 1  B A T T L E",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 3.sp
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Bottom Main Mode Selection Buttons
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Button 1: [ JOGAR VS CPU ]
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .border(2.dp, Color(0xFF00E676), RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF1B5E20), Color(0xFF00E676))
                                )
                            )
                            .clickable { showCpuDifficultyDialog = true }
                            .testTag("vs_cpu_button")
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = "VS CPU",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "JOGAR VS CPU",
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "DESAFIE O BOT LOCAL (${selectedDifficulty.displayName})",
                                    color = Color(0xFFE8F5E9),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // Button 2: [ JOGAR ONLINE 1v1 ]
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .border(2.dp, Color(0xFF7C4DFF), RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF4A148C), Color(0xFF7C4DFF))
                                )
                            )
                            .clickable {
                                lobbyTabMode = "menu"
                                onOpenOnlineLobby()
                            }
                            .testTag("online_1v1_button")
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = "Online 1v1",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "JOGAR ONLINE 1v1",
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "LOBBY MULTIPLAYER EM TEMPO REAL",
                                    color = Color(0xFFEDE7F6),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Nav Bar Section
            Column(
                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "v2.0 RETRO ENGINE  |  FULL PERFORMANCE STATS",
                    color = Color(0xFF4A5568),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { 
                        showShopDialog = false
                        showSettingsDialog = false
                        showProfileDialog = false
                        showLeaderboardDialog = false
                        showMissionsDialog = true
                    }) {
                        Icon(Icons.Default.List, contentDescription = "Missões", tint = Color.White)
                    }
                    IconButton(onClick = { 
                        showMissionsDialog = false
                        showSettingsDialog = false
                        showProfileDialog = false
                        showLeaderboardDialog = false
                        showShopDialog = true 
                    }) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Loja", tint = Color.White)
                    }
                    IconButton(onClick = { 
                        showMissionsDialog = false
                        showShopDialog = false
                        showSettingsDialog = false
                        showProfileDialog = false
                        showLeaderboardDialog = true 
                    }) {
                        Icon(Icons.Default.Public, contentDescription = "Ranking", tint = Color.White)
                    }
                    IconButton(onClick = { 
                        showMissionsDialog = false
                        showShopDialog = false
                        showProfileDialog = false
                        showLeaderboardDialog = false
                        showSettingsDialog = true 
                    }) {
                        Icon(Icons.Default.Settings, contentDescription = "Configurações", tint = Color.White)
                    }
                    IconButton(onClick = { 
                        showMissionsDialog = false
                        showShopDialog = false
                        showSettingsDialog = false
                        showLeaderboardDialog = false
                        showProfileDialog = true 
                    }) {
                        Icon(Icons.Default.Person, contentDescription = "Perfil", tint = Color.White)
                    }
                }
            }
        }

        // Settings Dialog
        if (showSettingsDialog) {
            Dialog(
                onDismissRequest = { showSettingsDialog = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                val screenHeight = LocalConfiguration.current.screenHeightDp.dp
                val maxModalHeight = minOf(screenHeight * 0.75f, screenHeight - 140.dp)

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .widthIn(max = 440.dp)
                        .heightIn(max = maxModalHeight)
                        .wrapContentHeight()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F1224))
                        .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        .testTag("settings_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Configurações",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "CONFIGURAÇÕES",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            IconButton(onClick = { showSettingsDialog = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Option 1: PERSONALIZAR CONTROLES
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .border(1.5.dp, Color(0xFFFFD600), RoundedCornerShape(10.dp))
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF2A2312))
                                    .clickable {
                                        showSettingsDialog = false
                                        onOpenControlsEditor()
                                    }
                                    .testTag("customize_controls_option")
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Tune,
                                        contentDescription = "Personalizar Controles",
                                        tint = Color(0xFFFFD600),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "PERSONALIZAR CONTROLES",
                                            color = Color(0xFFFFD600),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "ARRASTE, REDIMENSIONAR E OPACIDADE",
                                            color = Color(0xFFFFE082),
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }

                            // Option 2: HISTÓRICO DE DESEMPENHO
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .border(1.dp, Color(0xFF00E5FF), RoundedCornerShape(10.dp))
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0B2133))
                                    .clickable {
                                        showSettingsDialog = false
                                        onOpenHistory()
                                    }
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Leaderboard,
                                        contentDescription = "Histórico",
                                        tint = Color(0xFF00E5FF),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "HISTÓRICO DE DESEMPENHO",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF00E5FF))
                                .clickable { showSettingsDialog = false }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "FECHAR",
                                color = Color.Black,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Shop Modal
        if (showShopDialog) {
            ShopModal(
                inventory = gameState.inventory,
                items = listOf(
                    // BLOCOS
                    ShopItem("neon", "Padrão Neon", "blocos", 0, ""),
                    ShopItem("gb", "Game Boy Classic", "blocos", 200, ""),
                    ShopItem("cyber", "Cyberpunk Glow", "blocos", 500, ""),
                    ShopItem("fireice", "Fogo & Gelo", "blocos", 1000, ""),
                    ShopItem("gold", "Ouro Puro", "blocos", 2000, ""),
                    // FUNDOS
                    ShopItem("space", "Espaço Sombrio", "fundos", 0, ""),
                    ShopItem("matrix", "Matrix Code", "fundos", 300, ""),
                    ShopItem("sunset", "Sunset Synthwave", "fundos", 600, ""),
                    ShopItem("arena", "Arena Pixel Art", "fundos", 1200, ""),
                    // EFEITOS
                    ShopItem("sparks", "Faíscas Padrão", "efeitos", 0, ""),
                    ShopItem("explosion", "Explosão Pixels", "efeitos", 400, ""),
                    ShopItem("plasma", "Fogo / Plasma", "efeitos", 800, ""),
                    ShopItem("coins", "Chuva de Moedas", "efeitos", 1500, ""),
                    // MUSICAS
                    ShopItem("arcade", "Arcade v1", "musicas", 0, ""),
                    ShopItem("rush", "Battle Rush", "musicas", 350, ""),
                    ShopItem("synth", "Dark Synth Retro", "musicas", 700, "")
                ),
                onBuyItem = onBuyItem,
                onEquipItem = onEquipItem,
                onClose = { showShopDialog = false }
            )
        }

        // Missions Modal
        if (showMissionsDialog) {
            MissionsModal(
                missions = gameState.dailyMissions,
                onClaimReward = { onClaimMission(it.id) },
                onClose = { showMissionsDialog = false }
            )
        }

        // CPU Difficulty Selection Dialog
        if (showCpuDifficultyDialog) {
            Dialog(onDismissRequest = { showCpuDifficultyDialog = false }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .border(2.dp, Color(0xFF00E676), RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F1224))
                        .padding(20.dp)
                        .testTag("cpu_difficulty_dialog")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "DIFICULDADE DA CPU",
                            color = Color(0xFF00E676),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CpuDifficulty.entries.forEach { diff ->
                                val isSelected = selectedDifficulty == diff
                                val borderColor = when (diff) {
                                    CpuDifficulty.EASY -> Color(0xFF00E676)
                                    CpuDifficulty.MEDIUM -> Color(0xFF00E5FF)
                                    CpuDifficulty.HARD -> Color(0xFFFF1744)
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) borderColor else Color(0xFF2E355B),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) Color(0xFF1E2548) else Color(0xFF12152B))
                                        .clickable { selectedDifficulty = diff }
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = diff.displayName,
                                                color = borderColor,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = diff.description,
                                                color = Color(0xFFB0BEC5),
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .size(12.dp)
                                                    .clip(CircleShape)
                                                    .background(borderColor)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                                    .clickable { showCpuDifficultyDialog = false }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "CANCELAR",
                                    color = Color.LightGray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1.5f)
                                    .height(48.dp)
                                    .background(Color(0xFF00E676), RoundedCornerShape(8.dp))
                                    .clickable {
                                        showCpuDifficultyDialog = false
                                        onStartVsCpu(selectedDifficulty)
                                    }
                                    .testTag("start_vs_cpu_confirm_button")
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "INICIAR VS CPU",
                                    color = Color.Black,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Online Lobby Dialog
        if (gameState.isSearchingOnlineOpponent) {
            Dialog(onDismissRequest = onCloseOnlineLobby) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .border(2.dp, Color(0xFF7C4DFF), RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F1224))
                        .padding(20.dp)
                        .testTag("online_lobby_dialog")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = "Online",
                                tint = Color(0xFF7C4DFF),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "LOBBY MULTIPLAYER 1V1",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        if (gameState.onlineRoomStatus == "buscando") {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text(
                                    text = "⚡ JOGO RÁPIDO / MATCHMAKING",
                                    color = Color(0xFFFFD600),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00E5FF).copy(alpha = pulseAlpha))
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "Buscando oponente...",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                if (gameState.onlineRoomCode.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF1E2442), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 16.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "SALA: ${gameState.onlineRoomCode}",
                                            color = Color.LightGray,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }

                                Text(
                                    text = "Conectando automaticamente à primeira sala livre encontrada no Firebase...",
                                    color = Color(0xFF9E9E9E),
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center,
                                    fontFamily = FontFamily.Monospace
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .border(2.dp, Color(0xFFFF1744), RoundedCornerShape(8.dp))
                                        .background(Color(0xFF3E101B), RoundedCornerShape(8.dp))
                                        .clickable { onCancelQuickMatch() }
                                        .testTag("cancel_quick_match_button")
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "CANCELAR BUSCA",
                                        color = Color(0xFFFF5252),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        } else if (gameState.onlineRoomStatus == "aguardando") {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "SALA CRIADA COM SUCESSO!",
                                    color = Color(0xFF00E676),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )

                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFF1E2442), RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFF00E5FF), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 24.dp, vertical = 12.dp)
                                ) {
                                    Text(
                                        text = gameState.onlineRoomCode,
                                        color = Color(0xFFFFD600),
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 4.sp
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00E5FF).copy(alpha = pulseAlpha))
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "AGUARDANDO OPONENTE (JOGADOR 2)...",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Text(
                                    text = "Informe este código de 4 caracteres ao outro jogador para ele entrar.",
                                    color = Color(0xFF9E9E9E),
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center,
                                    fontFamily = FontFamily.Monospace
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                                        .clickable { onCloseOnlineLobby() }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "CANCELAR E VOLTAR",
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        } else if (lobbyTabMode == "join" || gameState.onlineRoomStatus == "entrando") {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "DIGITE O CÓDIGO DA SALA (4 CARACTERES):",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Center
                                )

                                OutlinedTextField(
                                    value = inputRoomCode,
                                    onValueChange = { if (it.length <= 4) inputRoomCode = it.uppercase() },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFF00E5FF),
                                        unfocusedBorderColor = Color(0xFF7C4DFF),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(onDone = {
                                        if (inputRoomCode.length == 4) {
                                            onJoinOnlineRoom(inputRoomCode)
                                        }
                                    }),
                                    placeholder = {
                                        Text(
                                            "EX: A8F3",
                                            color = Color.Gray,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("room_code_input")
                                )

                                if (gameState.onlineErrorMessage.isNotEmpty()) {
                                    Text(
                                        text = gameState.onlineErrorMessage,
                                        color = Color(0xFFFF1744),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                                            .clickable { lobbyTabMode = "menu" }
                                            .padding(8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "VOLTAR",
                                            color = Color.LightGray,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1.5f)
                                            .height(48.dp)
                                            .background(
                                                if (inputRoomCode.length == 4) Color(0xFF00E676) else Color.DarkGray,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable(enabled = inputRoomCode.length == 4) {
                                                onJoinOnlineRoom(inputRoomCode)
                                            }
                                            .testTag("confirm_join_room_button")
                                            .padding(8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "ENTRAR NA SALA",
                                            color = if (inputRoomCode.length == 4) Color.Black else Color.Gray,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "ESCOLHA COMO DESEJA CONECTAR:",
                                    color = Color(0xFFB0BEC5),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .border(1.5.dp, Color(0xFFFFD600), RoundedCornerShape(10.dp))
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF2C240E))
                                        .clickable { onStartQuickMatch() }
                                        .testTag("quick_match_button")
                                        .padding(horizontal = 16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Bolt,
                                            contentDescription = "Jogo Rápido",
                                            tint = Color(0xFFFFD600),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "JOGO RÁPIDO / ALEATÓRIO",
                                                color = Color(0xFFFFD600),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "BUSCA AUTOMÁTICA DE SALA ABERTA",
                                                color = Color(0xFFFFE082),
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .border(1.5.dp, Color(0xFF00E5FF), RoundedCornerShape(10.dp))
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF132338))
                                        .clickable { onCreateOnlineRoom() }
                                        .testTag("create_room_button")
                                        .padding(horizontal = 16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.AddCircleOutline,
                                            contentDescription = "Criar Sala",
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "CRIAR SALA PRIVADA",
                                                color = Color(0xFF00E5FF),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "GERAR CÓDIGO E CONVIDAR AMIGO",
                                                color = Color(0xFF80DEEA),
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .border(1.5.dp, Color(0xFF7C4DFF), RoundedCornerShape(10.dp))
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF23173B))
                                        .clickable {
                                            inputRoomCode = ""
                                            lobbyTabMode = "join"
                                        }
                                        .testTag("join_room_button")
                                        .padding(horizontal = 16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Login,
                                            contentDescription = "Entrar em Sala",
                                            tint = Color(0xFFB388FF),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "ENTRAR EM SALA",
                                                color = Color(0xFFB388FF),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "DIGITAR CÓDIGO DA SALA DE UM AMIGO",
                                                color = Color(0xFFD1C4E9),
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                                        .clickable { onCloseOnlineLobby() }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "CANCELAR",
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Rules / Instructions Dialog
        if (showRulesDialog) {
            Dialog(onDismissRequest = { showRulesDialog = false }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F1224))
                        .padding(20.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "REGRAS DO JOGO",
                            color = Color(0xFF00E5FF),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "1. PEÇAS PERMITIDAS:\n" +
                                    "Apenas formas retas horizontais: 1x1, 1x2, 1x3 e 1x4 sorteadas 100% aleatoriamente.\n\n" +
                                    "2. SISTEMA DE COMBOS:\n" +
                                    "Destruir linhas seguidas aplica multiplicadores de ataque (Combo x2 -> 1.5x, Combo x3 -> 2.0x).\n\n" +
                                    "3. SISTEMA DE ATAQUE 75%:\n" +
                                    "Ao destruir linhas, 75% x multiplicador de combo são enviados como peças rígidas de 1x1 (65%) e 1x2 (35%) para o oponente.\n\n" +
                                    "4. MODO ONLINE 1V1:\n" +
                                    "Use JOGO RÁPIDO para busca automática ou crie/entre em salas com código de 4 caracteres via Firebase.",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .background(Color(0xFF00E5FF), RoundedCornerShape(8.dp))
                                .clickable { showRulesDialog = false }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "ENTENDI!",
                                color = Color.Black,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Leaderboard / Tabela de Líderes Dialog
        if (showLeaderboardDialog) {
            Dialog(
                onDismissRequest = { showLeaderboardDialog = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                val screenHeight = LocalConfiguration.current.screenHeightDp.dp
                val maxModalHeight = minOf(screenHeight * 0.75f, screenHeight - 140.dp)

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .widthIn(max = 440.dp)
                        .heightIn(max = maxModalHeight)
                        .wrapContentHeight()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F1224))
                        .border(2.dp, Color(0xFFFFD600), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        .testTag("leaderboard_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Public,
                                    contentDescription = "Líderes",
                                    tint = Color(0xFFFFD600),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "TOP 10 MUNDIAL",
                                    color = Color(0xFFFFD600),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            IconButton(onClick = { showLeaderboardDialog = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                            }
                        }

                        Text(
                            text = "ESTATÍSTICAS EM TEMPO REAL (FIREBASE)",
                            color = Color(0xFF80DEEA),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (leaderboardLoading) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "CARREGANDO DADOS...",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else if (leaderboardError.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "ERRO: $leaderboardError",
                                        color = Color(0xFFFF1744),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else if (leaderboardList.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "NENHUM PLAYER CADASTRADO",
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else {
                                leaderboardList.forEachIndexed { index, entry ->
                                    val medal = when (index) {
                                        0 -> "🥇"
                                        1 -> "🥈"
                                        2 -> "🥉"
                                        else -> " #${index + 1}"
                                    }
                                    val isSelf = entry.id == getPlayerName().lowercase().trim()
                                    val rowBg = if (isSelf) Color(0xFF1B5E20) else if (index % 2 == 0) Color(0xFF14172E) else Color(0xFF0C0E1B)
                                    val textColor = if (isSelf) Color(0xFF00E676) else if (index < 3) Color(0xFFFFD600) else Color.White

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(rowBg)
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                text = medal,
                                                color = textColor,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace,
                                                modifier = Modifier.width(28.dp)
                                            )
                                            Column {
                                                Text(
                                                    text = if (isSelf) "${entry.nickname} (VOCÊ)" else entry.nickname,
                                                    color = textColor,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelf) FontWeight.Black else FontWeight.Bold,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                val (patentName, patentColor) = getPatentInfo(entry.pl)
                                                Text(
                                                    text = "$patentName (${entry.pl} PL)",
                                                    color = patentColor,
                                                    fontSize = 9.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "${entry.pl} PL",
                                                color = if (isSelf) Color(0xFF00E676) else Color(0xFFFFD600),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "${entry.total_vitorias} VIT",
                                                color = Color.LightGray,
                                                fontSize = 8.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.5.dp, Color(0xFFFFD600), RoundedCornerShape(8.dp))
                                .background(Color(0xFF231D10))
                                .clickable { showLeaderboardDialog = false }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "FECHAR",
                                color = Color(0xFFFFD600),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // First Time Nickname Entry Popup
        if (showFirstTimeNicknameDialog) {
            Dialog(onDismissRequest = { /* forces interaction to proceed */ }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .border(3.dp, Color(0xFF00E5FF), RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0C0E20))
                        .padding(20.dp)
                        .testTag("first_time_nickname_dialog")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "¡BEM-VINDO AO PIXEL CLASH!",
                            color = Color(0xFF00E5FF),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )

                        // Auth Tabs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFF2E355B), RoundedCornerShape(8.dp))
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF101328)),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (activeAuthTab == "signup") Color(0xFF7C4DFF) else Color.Transparent)
                                    .clickable {
                                        activeAuthTab = "signup"
                                        localErrorMessage = ""
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "CADASTRAR",
                                    color = if (activeAuthTab == "signup") Color.White else Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (activeAuthTab == "login") Color(0xFF00E5FF) else Color.Transparent)
                                    .clickable {
                                        activeAuthTab = "login"
                                        localErrorMessage = ""
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "ENTRAR",
                                    color = if (activeAuthTab == "login") Color.Black else Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Text(
                            text = if (activeAuthTab == "signup")
                                "Crie um Nickname único de até 12 caracteres e um PIN de 4 dígitos (obrigatório) para registrar-se:"
                            else
                                "Insira seu Nickname e seu PIN de 4 dígitos para carregar seus dados e progresso do Firebase:",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )

                        // Nickname Input
                        OutlinedTextField(
                            value = firstTimeInputName,
                            onValueChange = { newValue ->
                                firstTimeInputName = newValue.take(12) // max 12 characters
                            },
                            singleLine = true,
                            placeholder = {
                                Text(
                                    text = "Nickname (máx 12)...",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = if (activeAuthTab == "signup") Color(0xFF7C4DFF) else Color(0xFF00E5FF),
                                unfocusedBorderColor = Color(0xFF2E355B),
                                focusedContainerColor = Color(0xFF10142C),
                                unfocusedContainerColor = Color(0xFF0C0F22)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("first_time_nickname_input")
                        )

                        // PIN Input (Mandatory 4 digits)
                        OutlinedTextField(
                            value = firstTimeInputPin,
                            onValueChange = { newValue ->
                                if (newValue.length <= 4 && newValue.all { c -> c.isDigit() }) {
                                    firstTimeInputPin = newValue
                                }
                            },
                            singleLine = true,
                            placeholder = {
                                Text(
                                    text = "PIN (4 dígitos obrigatório)...",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFD600),
                                unfocusedBorderColor = Color(0xFF2E355B),
                                focusedContainerColor = Color(0xFF10142C),
                                unfocusedContainerColor = Color(0xFF0C0F22)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("first_time_pin_input")
                        )

                        if (localErrorMessage.isNotEmpty()) {
                            Text(
                                text = localErrorMessage,
                                color = Color(0xFFFF1744),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .background(
                                    if (isValidating) Color.Gray 
                                    else if (activeAuthTab == "signup") Color(0xFF7C4DFF) 
                                    else Color(0xFF00E5FF), 
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable(enabled = !isValidating) {
                                    val finalName = firstTimeInputName.trim().lowercase() // Normalized
                                    val finalPin = firstTimeInputPin.trim()
                                    if (finalName.isEmpty()) {
                                        localErrorMessage = "Por favor, digite um Nickname."
                                        return@clickable
                                    }
                                    if (finalPin.length != 4 || !finalPin.all { it.isDigit() }) {
                                        localErrorMessage = "O PIN de 4 dígitos é obrigatório."
                                        return@clickable
                                    }
                                    
                                    isValidating = true
                                    localErrorMessage = ""
                                    
                                    // Implementation of timeout
                                    val timeoutJob = scope.launch {
                                        kotlinx.coroutines.delay(4000)
                                        if (isValidating) {
                                            localErrorMessage = "Tiempo de espera agotado. Verifica tu conexión"
                                            isValidating = false
                                        }
                                    }

                                    try {
                                        onCheckNicknameExists(finalName) { exists ->
                                            timeoutJob.cancel()
                                            if (!isValidating) return@onCheckNicknameExists

                                            if (activeAuthTab == "signup") {
                                                if (exists) {
                                                    isValidating = false
                                                    localErrorMessage = "Este Nickname já está registrado. Faça login ou escolha outro nome."
                                                } else {
                                                    onSaveLocalPin(finalPin)
                                                    onSavePlayerName(finalName, finalPin)
                                                    currentNickname = finalName
                                                    isValidating = false
                                                }
                                            } else {
                                                // login
                                                if (!exists) {
                                                    isValidating = false
                                                    localErrorMessage = "El usuario no existe. Regístrate primero."
                                                } else {
                                                    onSaveLocalPin(finalPin)
                                                    onSavePlayerName(finalName, finalPin)
                                                    currentNickname = finalName
                                                    // We'll reset isValidating via LaunchedEffect when nicknameErrorMessage or Name changes
                                                }
                                            }
                                        }
                                    } catch (e: Exception) {
                                        timeoutJob.cancel()
                                        localErrorMessage = "Erro inesperado"
                                        isValidating = false
                                    }
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isValidating) "VERIFICANDO..." else if (activeAuthTab == "signup") "CADASTRAR" else "ENTRAR",
                                color = if (activeAuthTab == "signup" && !isValidating) Color.White else Color.Black,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Error Dialog when nicknameErrorMessage is not empty
        if (gameState.nicknameErrorMessage.isNotEmpty()) {
            Dialog(onDismissRequest = { onClearNicknameError() }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .border(3.dp, Color.Red, RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E0A0A))
                        .padding(20.dp)
                        .testTag("nickname_error_dialog")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "ERRO DE AUTENTICAÇÃO",
                            color = Color.Red,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = gameState.nicknameErrorMessage,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .background(Color.Red, RoundedCornerShape(8.dp))
                                .clickable { onClearNicknameError() },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "FECHAR",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // PIN validation Dialog for Profile Transfer
        if (gameState.nicknameShowPinPrompt) {
            var pinInput by remember { mutableStateOf("") }
            Dialog(onDismissRequest = { onCancelPinPrompt() }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .border(3.dp, Color(0xFFFFD600), RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1A1A00))
                        .padding(20.dp)
                        .testTag("nickname_pin_prompt_dialog")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "TRANSFERIR PERFIL",
                            color = Color(0xFFFFD600),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Este Nickname já pertence a outro jogador. Se for você, digite o PIN de 4 dígitos para importar seu perfil e histórico de vitórias:",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinInput = it },
                            singleLine = true,
                            placeholder = { Text("Digite o PIN...", color = Color.Gray, fontFamily = FontFamily.Monospace) },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFD600),
                                unfocusedBorderColor = Color(0xFF555500)
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("transfer_pin_input")
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1.0f)
                                    .height(44.dp)
                                    .background(Color.Gray, RoundedCornerShape(8.dp))
                                    .clickable { onCancelPinPrompt() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("CANCELAR", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1.0f)
                                    .height(44.dp)
                                    .background(Color(0xFFFFD600), RoundedCornerShape(8.dp))
                                    .clickable {
                                        if (pinInput.length == 4) {
                                            onConfirmPin(pinInput)
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("IMPORTAR", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Profile Dialog
        if (showProfileDialog) {
            Dialog(
                onDismissRequest = { showProfileDialog = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                var tempProfileNickname by remember { mutableStateOf(currentNickname) }
                var tempProfilePin by remember { mutableStateOf(getLocalPin()) }
                val currentPos = leaderboardList.indexOfFirst { it.id == getPlayerName().lowercase().trim() }
                val rankText = if (currentPos != -1) "#${currentPos + 1} GLOBAL" else "FORA DO TOP 10"
                val screenHeight = LocalConfiguration.current.screenHeightDp.dp
                val maxModalHeight = minOf(screenHeight * 0.75f, screenHeight - 140.dp)

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .widthIn(max = 440.dp)
                        .heightIn(max = maxModalHeight)
                        .wrapContentHeight()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F0B1E))
                        .border(2.dp, Color(0xFFE040FB), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        .testTag("profile_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PERFIL DO JOGADOR",
                                color = Color(0xFFE040FB),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            IconButton(onClick = { showProfileDialog = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Visual Avatar Box
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .border(3.dp, Color(0xFFE040FB), CircleShape)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2C103F)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = currentNickname.take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            // Stats Card
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0xFF2E1C4B), RoundedCornerShape(8.dp))
                                    .background(Color(0xFF140D2B))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceAround,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "VITÓRIAS",
                                            color = Color(0xFFB388FF),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "${gameState.wins}",
                                            color = Color(0xFF00E676),
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "PATENTE",
                                            color = Color(0xFFB388FF),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        val (patentName, patentColor) = getPatentInfo(gameState.pl)
                                        Text(
                                            text = patentName,
                                            color = patentColor,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "${gameState.pl} PL ($rankText)",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }

                            // Editable Nickname
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "ALTERAR NICKNAME:",
                                    color = Color(0xFFB388FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                OutlinedTextField(
                                    value = tempProfileNickname,
                                    onValueChange = { tempProfileNickname = it.take(12).trim() },
                                    singleLine = true,
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    ),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFFE040FB),
                                        unfocusedBorderColor = Color(0xFF422163)
                                    ),
                                    modifier = Modifier.fillMaxWidth().testTag("profile_nickname_input")
                                )
                            }

                            // Editable PIN
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "PIN DE SEGURANÇA (4 DÍGITOS):",
                                    color = Color(0xFFFFD600),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                OutlinedTextField(
                                    value = tempProfilePin,
                                    onValueChange = { newValue ->
                                        if (newValue.length <= 4 && newValue.all { c -> c.isDigit() }) {
                                            tempProfilePin = newValue
                                        }
                                    },
                                    singleLine = true,
                                    placeholder = {
                                        Text("Sem PIN", color = Color.Gray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                    },
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    ),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFFFFD600),
                                        unfocusedBorderColor = Color(0xFF555500)
                                    ),
                                    modifier = Modifier.fillMaxWidth().testTag("profile_pin_input")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF2E355B))
                                    .clickable { showProfileDialog = false },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("CANCELAR", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1.5f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE040FB))
                                    .clickable {
                                        if (tempProfileNickname.isNotEmpty()) {
                                            onSaveLocalPin(tempProfilePin)
                                            onSavePlayerName(tempProfileNickname, tempProfilePin)
                                            currentNickname = tempProfileNickname
                                            showProfileDialog = false
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("SALVAR ALTERAÇÕES", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}
