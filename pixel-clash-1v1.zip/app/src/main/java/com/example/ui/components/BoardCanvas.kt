package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.Cell
import com.example.model.PlayerState

@Composable
fun BoardCanvas(
    playerState: PlayerState,
    particleController: ParticleController,
    modifier: Modifier = Modifier,
    skinId: String = "neon",
    vfxId: String = "sparks"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "warningGlow")
    
    // Force periodic recomposition during line clearing for smooth fade
    val animTick by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(100),
            repeatMode = RepeatMode.Restart
        ),
        label = "animTick"
    )

    val warningAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    // Trigger destruction particles when lines are cleared
    LaunchedEffect(playerState.lastClearTime) {
        if (playerState.clearingRows.isNotEmpty()) {
            for (r in playerState.clearingRows) {
                particleController.triggerExplosion(
                    centerX = 180f,
                    centerY = r * 20f + 10f,
                    count = 20,
                    colors = listOf(Color(0xFF00E5FF), Color(0xFFFFD600), Color(0xFF00E676)),
                    vfxId = vfxId
                )
            }
        }
    }

    // Trigger destruction particles when receiving attack blocks
    LaunchedEffect(playerState.fallingGarbagePieces.size) {
        if (playerState.fallingGarbagePieces.isNotEmpty()) {
            particleController.triggerExplosion(
                centerX = 180f,
                centerY = 40f,
                count = 25,
                colors = listOf(Color(0xFFFF1744), Color(0xFFFF9100), Color(0xFF9E9E9E))
            )
        }
    }

    Box(
        modifier = modifier
            .testTag("player_board_container")
            .shadow(12.dp, RoundedCornerShape(8.dp), spotColor = Color(0xFF00E5FF))
            .border(
                width = 3.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF00E5FF),
                        Color(0xFF2979FF),
                        Color(0xFF1A237E)
                    )
                ),
                shape = RoundedCornerShape(8.dp)
            )
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0A0C16))
            .aspectRatio(10f / 20f)
    ) {
        Canvas(modifier = Modifier.fillMaxSize().testTag("player_board_canvas")) {
            val blockSize = size.width / PlayerState.BOARD_COLS
            val boardWidth = size.width
            val boardHeight = size.height

            // 1. Grid lines
            val gridColor = Color(0xFF181B2C)
            for (c in 1 until PlayerState.BOARD_COLS) {
                val x = c * blockSize
                drawLine(
                    color = gridColor,
                    start = Offset(x, 0f),
                    end = Offset(x, boardHeight),
                    strokeWidth = 1f
                )
            }
            for (r in 1 until PlayerState.BOARD_ROWS) {
                val y = r * blockSize
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(boardWidth, y),
                    strokeWidth = 1f
                )
            }

            // 2. Locked cells
            val now = System.currentTimeMillis()
            val clearAnimDuration = 400f // Matches ViewModel delay
            
            for (r in 0 until PlayerState.BOARD_ROWS) {
                val isRowClearing = playerState.isClearingLines && playerState.clearingRows.contains(r)
                val rowAlpha = if (isRowClearing) {
                    (1.0f - (now - playerState.lastClearTime) / clearAnimDuration).coerceIn(0f, 1f)
                } else 1.0f

                for (c in 0 until PlayerState.BOARD_COLS) {
                    val cell = playerState.board[r][c]
                    if (cell != null) {
                        PixelBlockDrawer.drawPixelBlock(
                            drawScope = this,
                            topLeft = Offset(c * blockSize, r * blockSize),
                            blockSize = blockSize,
                            cell = cell,
                            skinId = skinId,
                            alpha = rowAlpha
                        )
                    }
                }
            }

            // 2b. Visible falling 1x2 and 1x3 garbage pieces (dropping from top with soft drop speed)
            for (fp in playerState.fallingGarbagePieces) {
                if (fp.spawnDelayTicks == 0 && fp.y in 0 until PlayerState.BOARD_ROWS) {
                    val endCol = (fp.startCol + fp.size).coerceAtMost(PlayerState.BOARD_COLS)
                    for (c in fp.startCol until endCol) {
                        PixelBlockDrawer.drawPixelBlock(
                            drawScope = this,
                            topLeft = Offset(c * blockSize, fp.y * blockSize),
                            blockSize = blockSize,
                            cell = Cell.GARBAGE,
                            skinId = skinId
                        )
                    }
                }
            }

            // 3. Ghost piece projection
            val ghost = playerState.ghostPiece
            val current = playerState.currentPiece
            if (ghost != null && current != null && ghost.y != current.y) {
                for ((gx, gy) in ghost.getOccupiedCoordinates()) {
                    if (gy in 0 until PlayerState.BOARD_ROWS && gx in 0 until PlayerState.BOARD_COLS) {
                        PixelBlockDrawer.drawGhostBlock(
                            drawScope = this,
                            topLeft = Offset(gx * blockSize, gy * blockSize),
                            blockSize = blockSize,
                            color = current.type.primaryColor
                        )
                    }
                }
            }

            // 4. Active falling piece
            if (current != null) {
                val activeCell = Cell.fromPiece(current.type)
                for ((cx, cy) in current.getOccupiedCoordinates()) {
                    if (cy in 0 until PlayerState.BOARD_ROWS && cx in 0 until PlayerState.BOARD_COLS) {
                        PixelBlockDrawer.drawPixelBlock(
                            drawScope = this,
                            topLeft = Offset(cx * blockSize, cy * blockSize),
                            blockSize = blockSize,
                            cell = activeCell,
                            skinId = skinId
                        )
                    }
                }
            }

            // 5. Line clear flash effect
            if (playerState.clearingRows.isNotEmpty() && now - playerState.lastClearTime < 250) {
                val progress = (now - playerState.lastClearTime) / 250f
                val flashAlpha = (1f - progress).coerceIn(0f, 1f)
                for (r in playerState.clearingRows) {
                    drawRect(
                        color = Color.White.copy(alpha = flashAlpha * 0.85f),
                        topLeft = Offset(0f, r * blockSize),
                        size = Size(boardWidth, blockSize)
                    )
                }
            }

            // 6. Pending garbage danger meter on right edge
            if (playerState.pendingGarbage > 0) {
                val meterWidth = 5f
                val garbageHeight = (playerState.pendingGarbage * (blockSize / 5f)).coerceAtMost(boardHeight)
                drawRect(
                    color = Color(0xFFFF1744).copy(alpha = warningAlpha),
                    topLeft = Offset(boardWidth - meterWidth, boardHeight - garbageHeight),
                    size = Size(meterWidth, garbageHeight)
                )
            }
        }

        // Particle Overlay layer for destruction explosion sparks
        ParticleOverlay(controller = particleController)
    }
}
