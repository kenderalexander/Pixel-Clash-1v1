package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import kotlin.random.Random

data class PixelParticle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    val size: Float,
    var alpha: Float = 1.0f,
    val lifeTimeMs: Long = 500L,
    var ageMs: Long = 0L
)

class ParticleController {
    val particles = mutableStateListOf<PixelParticle>()

    fun triggerExplosion(
        centerX: Float,
        centerY: Float,
        count: Int = 30,
        colors: List<Color> = listOf(
            Color(0xFFFF1744),
            Color(0xFFFFD600),
            Color(0xFF00E5FF),
            Color(0xFF7C4DFF),
            Color(0xFF00E676)
        ),
        vfxId: String = "sparks"
    ) {
        val newParticles = mutableListOf<PixelParticle>()
        val actualCount = if (vfxId == "explosion") count * 2 else count
        
        for (i in 0 until actualCount) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            var speed = Random.nextFloat() * 12f + 4f
            var vx = Math.cos(angle.toDouble()).toFloat() * speed
            var vy = Math.sin(angle.toDouble()).toFloat() * speed - 2f
            var size = Random.nextFloat() * 8f + 6f
            var color = colors.random()
            var life = Random.nextLong(400L, 800L)

            when (vfxId) {
                "plasma" -> {
                    // Upward floating flames
                    vx = (Random.nextFloat() - 0.5f) * 4f
                    vy = -(Random.nextFloat() * 10f + 5f)
                    color = if (Random.nextBoolean()) Color(0xFFFF5722) else Color(0xFFFFD600)
                    size = Random.nextFloat() * 12f + 8f
                }
                "coins" -> {
                    // Bouncing coins
                    speed = Random.nextFloat() * 8f + 2f
                    vx = (Random.nextFloat() - 0.5f) * 15f
                    vy = -(Random.nextFloat() * 15f + 5f)
                    color = Color(0xFFFFD600)
                    size = 10f
                }
                "explosion" -> {
                    speed = Random.nextFloat() * 20f + 5f
                    vx = Math.cos(angle.toDouble()).toFloat() * speed
                    vy = Math.sin(angle.toDouble()).toFloat() * speed
                    size = Random.nextFloat() * 15f + 2f
                }
            }

            newParticles.add(
                PixelParticle(
                    x = centerX + (Random.nextFloat() - 0.5f) * 40f,
                    y = centerY + (Random.nextFloat() - 0.5f) * 40f,
                    vx = vx,
                    vy = vy,
                    color = color,
                    size = size,
                    lifeTimeMs = life
                )
            )
        }
        particles.addAll(newParticles)
    }

    fun update(deltaMs: Long) {
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.ageMs += deltaMs
            if (p.ageMs >= p.lifeTimeMs) {
                iterator.remove()
            } else {
                p.x += p.vx
                p.y += p.vy
                p.vy += 0.8f // Gravity effect on particles
                val progress = p.ageMs.toFloat() / p.lifeTimeMs.toFloat()
                p.alpha = (1.0f - progress).coerceIn(0f, 1f)
            }
        }
    }
}

@Composable
fun ParticleOverlay(
    controller: ParticleController,
    modifier: Modifier = Modifier
) {
    var tick by remember { mutableStateOf(0L) }

    LaunchedEffect(controller.particles.size) {
        while (controller.particles.isNotEmpty()) {
            delay(16) // ~60 FPS update loop
            controller.update(16)
            tick++
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        // Force recomposition on tick
        @Suppress("UNUSED_EXPRESSION")
        tick

        for (p in controller.particles) {
            drawRect(
                color = p.color.copy(alpha = p.alpha),
                topLeft = Offset(p.x, p.y),
                size = Size(p.size, p.size)
            )
        }
    }
}
