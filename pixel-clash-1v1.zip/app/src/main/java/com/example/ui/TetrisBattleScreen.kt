package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppScreen
import com.example.model.GameMode
import com.example.model.MatchStatus
import com.example.ui.components.AttackBanner
import com.example.ui.components.BoardCanvas
import com.example.ui.components.ControlsEditorScreen
import com.example.ui.components.GameOverDialog
import com.example.ui.components.MatchHistoryDialog
import com.example.ui.components.MiniBoardCanvas
import com.example.ui.components.ParticleController
import com.example.ui.components.ParticleOverlay
import com.example.ui.components.PiecePreviewBox
import com.example.ui.components.StartScreen
import com.example.ui.components.VirtualControls
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import kotlin.random.Random

@Composable
fun TetrisBattleScreen(
    viewModel: TetrisBattleViewModel = viewModel()
) {
    val gameState by viewModel.gameState.collectAsState()
    var showHistoryDialog by remember { mutableStateOf(false) }

    val shakeOffsetX = remember { Animatable(0f) }
    val shakeOffsetY = remember { Animatable(0f) }
    val particleController = viewModel.particleController

    // Screen Shake Effect when player receives garbage pieces or pending garbage warning
    LaunchedEffect(gameState.player.fallingGarbagePieces.size, gameState.player.pendingGarbage) {
        if (gameState.player.fallingGarbagePieces.isNotEmpty() || gameState.player.pendingGarbage > 0) {
            repeat(6) {
                shakeOffsetX.snapTo((Random.nextFloat() - 0.5f) * 14f)
                shakeOffsetY.snapTo((Random.nextFloat() - 0.5f) * 14f)
                delay(30)
            }
            shakeOffsetX.animateTo(0f)
            shakeOffsetY.animateTo(0f)
        }
    }

    if (gameState.currentScreen == AppScreen.MENU) {
        StartScreen(
            gameState = gameState,
            onStartVsCpu = { difficulty -> viewModel.startVsCpuMatch(difficulty) },
            onOpenOnlineLobby = { viewModel.openOnlineLobby() },
            onStartQuickMatch = { viewModel.startQuickMatch() },
            onCancelQuickMatch = { viewModel.cancelQuickMatch() },
            onCreateOnlineRoom = { viewModel.createOnlineRoom() },
            onJoinOnlineRoom = { code -> viewModel.joinOnlineRoom(code) },
            onConfirmOnlineMatch = { viewModel.confirmOnlineMatch() },
            onCloseOnlineLobby = { viewModel.closeOnlineLobby() },
            onOpenControlsEditor = { viewModel.openControlsEditor() },
            onOpenHistory = { showHistoryDialog = true },
            onToggleAudio = { viewModel.toggleAudio() },
            getPlayerName = { viewModel.getPlayerName() },
            getPlayerId = { viewModel.getPlayerId() },
            hasSavedNickname = { viewModel.hasSavedNickname() },
            onSavePlayerName = { name, pin -> viewModel.savePlayerName(name, pin) },
            onFetchLeaderboard = { onSuccess, onError -> viewModel.fetchLeaderboard(onSuccess, onError) },
            onConfirmPin = { pin -> viewModel.confirmNicknameWithPin(pin) },
            onCancelPinPrompt = { viewModel.cancelNicknamePinPrompt() },
            onClearNicknameError = { viewModel.clearNicknameError() },
            getLocalPin = { viewModel.getLocalPin() },
            onSaveLocalPin = { pin -> viewModel.saveLocalPin(pin) },
            onCheckNicknameExists = { name, onResult -> viewModel.checkNicknameExists(name, onResult) },
            getPatentInfo = { pl -> viewModel.getPatentInfo(pl) },
            onBuyItem = { item -> viewModel.buyItem(item) },
            onEquipItem = { item -> viewModel.equipItem(item) },
            onClaimMission = { missionId -> viewModel.claimMission(missionId) }
        )

        if (showHistoryDialog) {
            MatchHistoryDialog(
                stats = viewModel.getAggregatedStats(),
                history = viewModel.getMatchHistory(),
                onClearHistory = { viewModel.clearMatchHistory() },
                onDismiss = { showHistoryDialog = false }
            )
        }
        return
    }

    if (gameState.currentScreen == AppScreen.CUSTOMIZE_CONTROLS) {
        ControlsEditorScreen(
            initialSettings = gameState.controlSettings,
            onSaveSettings = { updatedSettings -> viewModel.saveControlSettings(updatedSettings) },
            onResetDefaults = { viewModel.resetControlSettings() },
            onCancel = { viewModel.navigateToMenu() }
        )
        return
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tetris_battle_screen"),
        containerColor = Color(0xFF070810)
    ) { innerPadding ->
        val equippedSkin = gameState.inventory.equippedItems["blocos"] ?: "neon"
        val equippedVfx = gameState.inventory.equippedItems["efeitos"] ?: "sparks"
        val equippedBgm = gameState.inventory.equippedItems["musicas"] ?: "arcade"
        val equippedBg = gameState.inventory.equippedItems["fundos"] ?: "space"

        val bgBrush = when (equippedBg) {
            "matrix" -> Brush.verticalGradient(listOf(Color(0xFF001100), Color(0xFF003300), Color(0xFF000000)))
            "sunset" -> Brush.verticalGradient(listOf(Color(0xFF311B92), Color(0xFFAD1457), Color(0xFFF48FB1)))
            "arena" -> Brush.verticalGradient(listOf(Color(0xFF1A237E), Color(0xFF283593), Color(0xFF3949AB)))
            else -> Brush.verticalGradient(
                listOf(
                    Color(0xFF0C0E1C),
                    Color(0xFF080912),
                    Color(0xFF05060A)
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(bgBrush)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 8.dp, end = 8.dp, top = 2.dp, bottom = 4.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // ==========================================
                // 1. TOP ARCADE HEADER BAR
                // ==========================================
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.navigateToMenu() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("header_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "Menu Principal",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Text(
                            text = if (gameState.gameMode == GameMode.VS_CPU)
                                "VS CPU [${gameState.cpuDifficulty.displayName}]"
                            else
                                "ONLINE 1V1 [${gameState.onlineRoomCode}]",
                            color = Color(0xFF00E5FF),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.toggleAudio() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("audio_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (gameState.isAudioEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                contentDescription = "Audio Toggle",
                                tint = if (gameState.isAudioEnabled) Color(0xFFFFD600) else Color.Gray,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.startNewMatch() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("restart_match_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reiniciar",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.togglePause() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("pause_button")
                        ) {
                            Icon(
                                imageVector = if (gameState.matchStatus == MatchStatus.PAUSED)
                                    Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = "Pausa",
                                tint = Color(0xFFFF4081),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // ==========================================
                // 2. CENTER DUAL BATTLE ARENA (LEFT PLAYER | RIGHT OPPONENT)
                // ==========================================
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // LEFT SIDE: Main Player Screen (10x20)
                    Column(
                        modifier = Modifier.weight(0.62f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Player Header Info
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "VOCÊ",
                                color = Color(0xFF00E5FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "PTS: ${gameState.player.score}",
                                color = Color(0xFFFFD600),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "L: ${gameState.player.linesCleared}",
                                color = Color(0xFF00E676),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Main 10x20 Board with Particle Overlay and Screen Shake
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            BoardCanvas(
                                playerState = gameState.player,
                                particleController = particleController,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .offset { IntOffset(shakeOffsetX.value.roundToInt(), shakeOffsetY.value.roundToInt()) },
                                skinId = equippedSkin,
                                vfxId = equippedVfx
                            )
                            ParticleOverlay(controller = particleController)

                            // High-impact combo indicator
                            if (gameState.player.combo > 1) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.Black.copy(alpha = 0.8f))
                                        .border(2.dp, Color(0xFFFF4081), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .testTag("combo_visual_overlay"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "COMBO",
                                            color = Color(0xFF00E5FF),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace,
                                            letterSpacing = 2.sp
                                        )
                                        Text(
                                            text = "x${gameState.player.combo}",
                                            color = Color(0xFFFFD600),
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace,
                                            letterSpacing = 1.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // RIGHT SIDE: Opponent Mini Screen (Top Right) + Next/Hold/Stats
                    Column(
                        modifier = Modifier.weight(0.38f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // TOP RIGHT: Mirrored Mini Opponent Board (10x20)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            MiniBoardCanvas(
                                opponentState = gameState.opponent,
                                modifier = Modifier.fillMaxWidth(),
                                skinId = equippedSkin
                            )

                            // Opponent Combo Indicator
                            if (gameState.opponent.combo > 1) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.Black.copy(alpha = 0.8f))
                                        .border(1.5.dp, Color(0xFFFF4081), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "COMBO",
                                            color = Color(0xFFB388FF),
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "x${gameState.opponent.combo}",
                                            color = Color(0xFFFFD600),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Preview Card (Next Only)
                        PiecePreviewBox(
                            title = "PRÓX",
                            pieceType = gameState.player.nextPiece,
                            tag = "next_piece_box",
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Side HUD Stats Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFF262A43), RoundedCornerShape(6.dp))
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0F1120))
                                .padding(vertical = 4.dp, horizontal = 6.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                if (gameState.player.combo > 1) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "COMBO",
                                            color = Color(0xFFFF4081),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "${gameState.player.combo}x",
                                            color = Color(0xFFFFD600),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }

                                if (gameState.player.pendingGarbage > 0) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "BLOQUEIO",
                                            color = Color(0xFFFF1744),
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "+${gameState.player.pendingGarbage}B",
                                            color = Color(0xFFFF1744),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // ==========================================
                // 3. VIRTUAL CONTROLS (Left, Right, Rotate, Fast Drop, Down)
                // ==========================================
                VirtualControls(
                    onLeft = { viewModel.moveLeft() },
                    onRight = { viewModel.moveRight() },
                    onRotate = { viewModel.rotate() },
                    onHardDrop = { viewModel.hardDrop() },
                    onSoftDrop = { viewModel.softDrop() },
                    controlSettings = gameState.controlSettings
                )
            }

            // Floating attack banner when garbage lines are exchanged
            AttackBanner(
                attackEvents = gameState.attackEvents,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 44.dp)
            )

            // Game over / Victory popup with Detailed Statistics
            GameOverDialog(
                gameState = gameState,
                matchDurationSeconds = gameState.matchDurationSeconds,
                totalAttacksSent = gameState.totalAttacksSent,
                onRestart = { viewModel.startNewMatch() },
                onOpenHistory = { showHistoryDialog = true },
                onMenu = { viewModel.navigateToMenu() }
            )

            // Performance History Dialog
            if (showHistoryDialog) {
                MatchHistoryDialog(
                    stats = viewModel.getAggregatedStats(),
                    history = viewModel.getMatchHistory(),
                    onClearHistory = { viewModel.clearMatchHistory() },
                    onDismiss = { showHistoryDialog = false }
                )
            }
        }
    }
}
