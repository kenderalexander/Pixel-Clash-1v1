package com.example.ui

import android.app.Application
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundManager
import com.example.engine.OpponentAI
import com.example.engine.TetrisEngine
import com.example.history.MatchHistoryManager
import com.example.model.AggregatedStats
import com.example.model.AppScreen
import com.example.model.AttackEvent
import com.example.model.ControlSettings
import com.example.model.CpuDifficulty
import com.example.model.GameMode
import com.example.model.MatchRecord
import com.example.model.MatchStatus
import com.example.model.Mission
import com.example.model.PieceType
import com.example.model.PlayerState
import com.example.model.PlayerInventory
import com.example.model.ShopItem
import com.example.model.Tetromino
import com.example.model.VersusGameState
import com.example.network.FirebaseRealtimeManager
import com.example.ui.components.ParticleController
import com.example.settings.ControlSettingsManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

class TetrisBattleViewModel(application: Application) : AndroidViewModel(application) {

    val soundManager = SoundManager(application)
    private val opponentAI = OpponentAI()
    private val firebaseManager = FirebaseRealtimeManager()
    private val controlSettingsManager = ControlSettingsManager(application)
    private val matchHistoryManager = MatchHistoryManager(application)

    private val playerId = "P_${Random.nextInt(10000, 99999)}"

    private var matchStartTimeMs: Long = System.currentTimeMillis()
    private var totalAttacksSentCounter: Int = 0

    private val _gameState = MutableStateFlow(VersusGameState(controlSettings = controlSettingsManager.loadSettings()))
    val gameState: StateFlow<VersusGameState> = _gameState.asStateFlow()

    init {
        val name = controlSettingsManager.getPlayerName()
        if (name.isNotEmpty()) {
            syncPlayerProfileFromCloud(name)
        }
        initializeMissions()
    }

    private fun initializeMissions() {
        _gameState.update {
            it.copy(
                dailyMissions = listOf(
                    Mission("m1", "Iniciante", "Limpe 10 linhas em uma partida", 50, 0, 10, false, false),
                    Mission("m2", "Ganhador", "Vença 3 partidas VS CPU", 100, 0, 3, false, false),
                    Mission("m3", "Especialista em Tetris", "Limpe 4 linhas simultaneamente", 150, 0, 1, false, false)
                )
            )
        }
    }

    fun buyItem(item: ShopItem) {
        val currentState = _gameState.value
        val inventory = currentState.inventory
        if (inventory.coins >= item.price && !inventory.boughtItems.contains(item.id)) {
            val newCoins = inventory.coins - item.price
            val newBoughtItems = inventory.boughtItems + item.id
            val newInventory = inventory.copy(coins = newCoins, boughtItems = newBoughtItems)
            
            _gameState.update { it.copy(inventory = newInventory, coins = newCoins) }
            
            val name = getPlayerName()
            if (name.isNotEmpty()) {
                firebaseManager.updatePlayerProgression(name, currentState.pl, newCoins, newInventory)
            }
            soundManager.playVictory() // Play a sound for purchase
        }
    }

    fun equipItem(item: ShopItem) {
        val currentState = _gameState.value
        val inventory = currentState.inventory
        if (inventory.boughtItems.contains(item.id)) {
            val newEquipped = inventory.equippedItems.toMutableMap()
            newEquipped[item.itemCategory] = item.id
            val newInventory = inventory.copy(equippedItems = newEquipped)
            
            _gameState.update { it.copy(inventory = newInventory) }
            
            val name = getPlayerName()
            if (name.isNotEmpty()) {
                firebaseManager.updatePlayerProgression(name, currentState.pl, currentState.inventory.coins, newInventory)
            }
            soundManager.playRotate() // Feedback
        }
    }

    fun claimMission(missionId: String) {
        val currentState = _gameState.value
        val missions = currentState.dailyMissions.toMutableList()
        val index = missions.indexOfFirst { it.id == missionId }
        if (index != -1) {
            val mission = missions[index]
            if (mission.isCompleted && !mission.isClaimed) {
                val newMission = mission.copy(isClaimed = true)
                missions[index] = newMission
                
                val newCoins = currentState.inventory.coins + mission.reward
                val newInventory = currentState.inventory.copy(coins = newCoins)
                
                _gameState.update { 
                    it.copy(
                        dailyMissions = missions,
                        inventory = newInventory,
                        coins = newCoins
                    )
                }
                
                val name = getPlayerName()
                if (name.isNotEmpty()) {
                    firebaseManager.updatePlayerProgression(name, currentState.pl, newCoins, newInventory)
                }
                soundManager.playVictory()
            }
        }
    }

    private fun updateMissionProgress(missionId: String, amount: Int, isSet: Boolean = false) {
        _gameState.update { state ->
            val missions = state.dailyMissions.toMutableList()
            val index = missions.indexOfFirst { it.id == missionId }
            if (index != -1) {
                val m = missions[index]
                if (!m.isCompleted) {
                    val newProgress = if (isSet) amount else m.progress + amount
                    val isNowCompleted = newProgress >= m.goal
                    missions[index] = m.copy(
                        progress = newProgress.coerceAtMost(m.goal),
                        isCompleted = isNowCompleted
                    )
                    if (isNowCompleted) soundManager.playVictory()
                }
            }
            state.copy(dailyMissions = missions)
        }
    }

    fun syncPlayerProfileFromCloud(nickname: String) {
        firebaseManager.fetchPlayerProfile(
            nickname = nickname,
            deviceId = controlSettingsManager.getDeviceId(),
            pin = controlSettingsManager.getPlayerPin(),
            onPinRequired = {
                _gameState.update {
                    it.copy(
                        nicknameShowPinPrompt = true,
                        nicknameToVerify = nickname,
                        nicknameErrorMessage = ""
                    )
                }
            },
            onSuccess = { fetchedNickname, pl, inventory, totalVitorias, level, layout, savedPin ->
                controlSettingsManager.savePlayerName(fetchedNickname)
                controlSettingsManager.saveSettings(layout)
                controlSettingsManager.savePlayerPin(savedPin)
                _gameState.update {
                    it.copy(
                        controlSettings = layout,
                        wins = totalVitorias,
                        pl = pl,
                        inventory = inventory,
                        nicknameShowPinPrompt = false,
                        nicknameToVerify = "",
                        nicknameErrorMessage = ""
                    )
                }
            },
            onError = { errorMsg ->
                _gameState.update {
                    it.copy(
                        nicknameErrorMessage = errorMsg,
                        nicknameShowPinPrompt = false
                    )
                }
            }
        )
    }

    fun openControlsEditor() {
        _gameState.update {
            it.copy(
                currentScreen = AppScreen.CUSTOMIZE_CONTROLS,
                isSearchingOnlineOpponent = false
            )
        }
    }

    fun saveControlSettings(settings: ControlSettings) {
        controlSettingsManager.saveSettings(settings)
        _gameState.update {
            it.copy(
                controlSettings = settings,
                currentScreen = AppScreen.MENU
            )
        }
        val nickname = getPlayerName()
        if (nickname.isNotEmpty()) {
            firebaseManager.savePlayerLayout(nickname, settings)
        }
    }

    fun resetControlSettings(): ControlSettings {
        val defaults = controlSettingsManager.resetToDefaults()
        _gameState.update {
            it.copy(controlSettings = defaults)
        }
        val nickname = getPlayerName()
        if (nickname.isNotEmpty()) {
            firebaseManager.savePlayerLayout(nickname, defaults)
        }
        return defaults
    }

    fun getMatchHistory(): List<MatchRecord> {
        return matchHistoryManager.getHistory()
    }

    fun getAggregatedStats(): AggregatedStats {
        return matchHistoryManager.getAggregatedStats()
    }

    fun clearMatchHistory() {
        matchHistoryManager.clearHistory()
    }

    fun getPlayerName(): String {
        return controlSettingsManager.getPlayerName()
    }

    fun hasSavedNickname(): Boolean {
        return controlSettingsManager.getPlayerName().isNotEmpty()
    }

    fun checkNicknameExists(name: String, onResult: (Boolean) -> Unit) {
        firebaseManager.checkNicknameExists(name, onResult)
    }

    fun savePlayerName(name: String, pin: String = "") {
        firebaseManager.fetchPlayerProfile(
            nickname = name,
            deviceId = controlSettingsManager.getDeviceId(),
            pin = pin,
            onPinRequired = {
                _gameState.update {
                    it.copy(
                        nicknameShowPinPrompt = true,
                        nicknameToVerify = name,
                        nicknameErrorMessage = ""
                    )
                }
            },
            onSuccess = { fetchedNickname, pl, inventory, totalVitorias, level, layout, savedPin ->
                controlSettingsManager.savePlayerName(fetchedNickname)
                controlSettingsManager.saveSettings(layout)
                controlSettingsManager.savePlayerPin(savedPin)
                _gameState.update {
                    it.copy(
                        controlSettings = layout,
                        wins = totalVitorias,
                        pl = pl,
                        inventory = inventory,
                        nicknameShowPinPrompt = false,
                        nicknameToVerify = "",
                        nicknameErrorMessage = ""
                    )
                }
            },
            onError = { errorMsg ->
                _gameState.update {
                    it.copy(
                        nicknameErrorMessage = errorMsg,
                        nicknameShowPinPrompt = false
                    )
                }
            }
        )
    }

    fun confirmNicknameWithPin(pin: String) {
        val nickname = _gameState.value.nicknameToVerify
        if (nickname.isNotEmpty()) {
            savePlayerName(nickname, pin)
        }
    }

    fun clearNicknameError() {
        _gameState.update {
            it.copy(
                nicknameErrorMessage = ""
            )
        }
    }

    fun cancelNicknamePinPrompt() {
        _gameState.update {
            it.copy(
                nicknameShowPinPrompt = false,
                nicknameToVerify = "",
                nicknameErrorMessage = ""
            )
        }
    }

    fun getLocalPin(): String {
        return controlSettingsManager.getPlayerPin()
    }

    fun saveLocalPin(pin: String) {
        val name = controlSettingsManager.getPlayerName()
        if (name.isNotEmpty() && pin.length == 4) {
            controlSettingsManager.savePlayerPin(pin)
            firebaseManager.updateDeviceIdAndPin(name.lowercase().trim(), controlSettingsManager.getDeviceId(), pin)
        }
    }

    fun getPlayerId(): String {
        return playerId
    }

    fun fetchLeaderboard(
        onSuccess: (List<com.example.network.LeaderboardEntry>) -> Unit,
        onError: (String) -> Unit
    ) {
        firebaseManager.fetchLeaderboard(onSuccess, onError)
    }

    fun getPatentInfo(pl: Int): Pair<String, Color> {
        return when {
            pl >= 2000 -> "🏆 Mestre Pixel" to Color(0xFFFFD700)
            pl >= 1500 -> "💎 Diamante Pixel" to Color(0xFF00E5FF)
            pl >= 1000 -> "🛡️ Platina Pixel" to Color(0xFF9E9E9E)
            pl >= 600 -> "🥇 Ouro Pixel" to Color(0xFFFFD600)
            pl >= 300 -> "🥈 Prata Pixel" to Color(0xFFB0BEC5)
            else -> "🥉 Bronze Pixel" to Color(0xFF8D6E63)
        }
    }

    fun awardMatchCoins(isOnline: Boolean) {
        val earned = if (isOnline) 50 else 20
        _gameState.update { it.copy(inventory = it.inventory.copy(coins = it.inventory.coins + earned)) }
        val nickname = getPlayerName()
        if (nickname.isNotEmpty()) {
            firebaseManager.updatePlayerProgression(nickname, _gameState.value.pl, _gameState.value.inventory.coins, _gameState.value.inventory)
        }
    }

    private var playerLoopJob: Job? = null
    private var opponentLoopJob: Job? = null
    private var garbageFallingJob: Job? = null
    val particleController = ParticleController()

    private fun nextPlayerPiece(): PieceType {
        return PieceType.getRandomPiece()
    }

    private fun nextOpponentPiece(): PieceType {
        return PieceType.getRandomPiece()
    }

    fun startVsCpuMatch(difficulty: CpuDifficulty = CpuDifficulty.MEDIUM) {
        firebaseManager.stopRoomListener()
        _gameState.update {
            it.copy(
                currentScreen = AppScreen.GAME_VS_CPU,
                gameMode = GameMode.VS_CPU,
                cpuDifficulty = difficulty,
                isSearchingOnlineOpponent = false
            )
        }
        startNewMatch()
    }

    fun openOnlineLobby() {
        _gameState.update {
            it.copy(
                isSearchingOnlineOpponent = true,
                onlineRoomCode = "",
                onlineRoomStatus = "menu",
                onlineErrorMessage = ""
            )
        }
    }

    fun startQuickMatch() {
        _gameState.update {
            it.copy(
                isSearchingOnlineOpponent = true,
                onlineRoomStatus = "buscando",
                onlineErrorMessage = ""
            )
        }

        firebaseManager.findQuickMatch(
            playerId = playerId,
            onFound = { foundRoomCode ->
                joinOnlineRoom(foundRoomCode)
            },
            onNotFound = {
                val roomCode = firebaseManager.generateRoomCode()
                _gameState.update {
                    it.copy(
                        isSearchingOnlineOpponent = true,
                        onlineRoomCode = roomCode,
                        isPlayer1 = true,
                        onlineRoomStatus = "buscando",
                        onlineErrorMessage = ""
                    )
                }

                firebaseManager.createRoom(
                    roomCode = roomCode,
                    playerId = playerId,
                    onSuccess = {
                        listenToOnlineRoom(roomCode)
                    },
                    onError = { err ->
                        _gameState.update {
                            it.copy(
                                onlineRoomStatus = "erro",
                                onlineErrorMessage = err
                            )
                        }
                    }
                )
            }
        )
    }

    fun cancelQuickMatch() {
        val currentCode = _gameState.value.onlineRoomCode
        if (currentCode.isNotEmpty() && _gameState.value.isPlayer1) {
            firebaseManager.deleteRoom(currentCode)
        }
        firebaseManager.stopRoomListener()
        _gameState.update {
            it.copy(
                isSearchingOnlineOpponent = true,
                onlineRoomStatus = "menu",
                onlineRoomCode = "",
                onlineErrorMessage = ""
            )
        }
    }

    fun createOnlineRoom() {
        val roomCode = firebaseManager.generateRoomCode()
        _gameState.update {
            it.copy(
                isSearchingOnlineOpponent = true,
                onlineRoomCode = roomCode,
                isPlayer1 = true,
                onlineRoomStatus = "aguardando",
                onlineErrorMessage = ""
            )
        }

        firebaseManager.createRoom(
            roomCode = roomCode,
            playerId = playerId,
            onSuccess = {
                listenToOnlineRoom(roomCode)
            },
            onError = { err ->
                _gameState.update {
                    it.copy(
                        onlineRoomStatus = "erro",
                        onlineErrorMessage = err
                    )
                }
            }
        )
    }

    fun joinOnlineRoom(inputCode: String) {
        val code = inputCode.trim().uppercase()
        if (code.length != 4) {
            _gameState.update {
                it.copy(onlineErrorMessage = "CÓDIGO INVÁLIDO (DIGITE 4 CARACTERES)")
            }
            return
        }

        _gameState.update {
            it.copy(
                onlineRoomStatus = "entrando",
                onlineErrorMessage = ""
            )
        }

        firebaseManager.joinRoom(
            roomCode = code,
            playerId = playerId,
            onSuccess = { roomState ->
                _gameState.update {
                    it.copy(
                        isSearchingOnlineOpponent = false,
                        onlineRoomCode = code,
                        isPlayer1 = false,
                        onlineRoomStatus = "em_jogo",
                        currentScreen = AppScreen.GAME_ONLINE,
                        gameMode = GameMode.ONLINE_1V1
                    )
                }
                listenToOnlineRoom(code)
                startNewMatch()
            },
            onError = { err ->
                _gameState.update {
                    it.copy(
                        onlineRoomStatus = "erro",
                        onlineErrorMessage = err
                    )
                }
            }
        )
    }

    private fun listenToOnlineRoom(roomCode: String) {
        firebaseManager.listenToRoom(roomCode) { roomState ->
            val currentState = _gameState.value
            val isP1 = currentState.isPlayer1

            if (isP1 && roomState.estado == "em_jogo" && currentState.isSearchingOnlineOpponent) {
                _gameState.update {
                    it.copy(
                        isSearchingOnlineOpponent = false,
                        currentScreen = AppScreen.GAME_ONLINE,
                        gameMode = GameMode.ONLINE_1V1,
                        onlineRoomStatus = "em_jogo"
                    )
                }
                startNewMatch()
            }

            val opponentBoardStr = if (isP1) roomState.p2BoardStr else roomState.p1BoardStr
            val opponentScore = if (isP1) roomState.p2Score else roomState.p1Score
            val opponentLines = if (isP1) roomState.p2Lines else roomState.p1Lines
            val opponentGameOver = if (isP1) roomState.p2GameOver else roomState.p1GameOver

            val deserializedBoard = firebaseManager.deserializeBoard(opponentBoardStr)

            val attackCount = if (isP1) roomState.attackForP1 else roomState.attackForP2
            var newPlayerFalling = currentState.player.fallingGarbagePieces

            if (attackCount > 0) {
                soundManager.playGarbageIncoming()
                val createdWave = TetrisEngine.createFallingGarbagePieceWave(
                    currentState.player.board,
                    currentState.player.fallingGarbagePieces,
                    attackCount
                )
                newPlayerFalling = newPlayerFalling + createdWave
                firebaseManager.clearPendingAttacks(roomCode, isP1)
            }

            val updatedPlayerPending = newPlayerFalling.sumOf { it.size }

            _gameState.update { state ->
                val currentOpponent = state.opponent
                state.copy(
                    opponent = currentOpponent.copy(
                        board = deserializedBoard,
                        score = opponentScore,
                        linesCleared = opponentLines,
                        isGameOver = opponentGameOver
                    ),
                    player = state.player.copy(
                        fallingGarbagePieces = newPlayerFalling,
                        pendingGarbage = updatedPlayerPending
                    )
                )
            }

            if (opponentGameOver && currentState.matchStatus == MatchStatus.PLAYING) {
                onMatchVictory()
            }
        }
    }

    fun confirmOnlineMatch() {
        _gameState.update {
            it.copy(
                currentScreen = AppScreen.GAME_ONLINE,
                gameMode = GameMode.ONLINE_1V1,
                isSearchingOnlineOpponent = false
            )
        }
        startNewMatch()
    }

    fun closeOnlineLobby() {
        val currentCode = _gameState.value.onlineRoomCode
        if (currentCode.isNotEmpty() && _gameState.value.isPlayer1 && _gameState.value.matchStatus != MatchStatus.PLAYING) {
            firebaseManager.deleteRoom(currentCode)
        }
        firebaseManager.stopRoomListener()
        _gameState.update {
            it.copy(
                isSearchingOnlineOpponent = false,
                onlineRoomStatus = "menu",
                onlineRoomCode = ""
            )
        }
    }

    fun navigateToMenu() {
        playerLoopJob?.cancel()
        opponentLoopJob?.cancel()
        garbageFallingJob?.cancel()

        val currentCode = _gameState.value.onlineRoomCode
        if (currentCode.isNotEmpty() && _gameState.value.isPlayer1) {
            firebaseManager.deleteRoom(currentCode)
        }

        firebaseManager.stopRoomListener()
        soundManager.stopBgm()
        _gameState.update {
            it.copy(
                currentScreen = AppScreen.MENU,
                matchStatus = MatchStatus.STARTING,
                isSearchingOnlineOpponent = false
            )
        }
    }

    private fun startBgmWithEquipped() {
        val equippedBgm = _gameState.value.inventory.equippedItems["musicas"] ?: "arcade"
        soundManager.startBgm(equippedBgm)
    }

    fun startNewMatch() {
        playerLoopJob?.cancel()
        opponentLoopJob?.cancel()
        garbageFallingJob?.cancel()

        matchStartTimeMs = System.currentTimeMillis()
        totalAttacksSentCounter = 0

        startBgmWithEquipped()

        val pFirst = nextPlayerPiece()
        val pNext = nextPlayerPiece()
        val pSpawned = Tetromino.spawn(pFirst)

        val oFirst = nextOpponentPiece()
        val oNext = nextOpponentPiece()
        val oSpawned = Tetromino.spawn(oFirst)

        _gameState.update { current ->
            current.copy(
                player = PlayerState(
                    board = List(PlayerState.BOARD_ROWS) { List(PlayerState.BOARD_COLS) { null } },
                    currentPiece = pSpawned,
                    ghostPiece = TetrisEngine.calculateGhost(
                        List(PlayerState.BOARD_ROWS) { List(PlayerState.BOARD_COLS) { null } },
                        pSpawned
                    ),
                    nextPiece = pNext,
                    holdPiece = null,
                    canHold = true,
                    score = 0,
                    linesCleared = 0,
                    level = 1,
                    pendingGarbage = 0,
                    fallingGarbagePieces = emptyList(),
                    combo = 0,
                    isGameOver = false
                ),
                opponent = PlayerState(
                    board = List(PlayerState.BOARD_ROWS) { List(PlayerState.BOARD_COLS) { null } },
                    currentPiece = oSpawned,
                    ghostPiece = null,
                    nextPiece = oNext,
                    holdPiece = null,
                    canHold = true,
                    score = 0,
                    linesCleared = 0,
                    level = 1,
                    pendingGarbage = 0,
                    fallingGarbagePieces = emptyList(),
                    combo = 0,
                    isGameOver = false
                ),
                matchStatus = MatchStatus.PLAYING,
                attackEvents = emptyList(),
                matchDurationSeconds = 0L,
                totalAttacksSent = 0
            )
        }

        startPlayerLoop()

        if (_gameState.value.gameMode == GameMode.VS_CPU) {
            startOpponentLoop()
        }

        startGarbageFallingLoop()

        if (_gameState.value.gameMode == GameMode.ONLINE_1V1) {
            syncOnlinePlayerState()
        }
    }

    private fun syncOnlinePlayerState() {
        val state = _gameState.value
        if (state.gameMode != GameMode.ONLINE_1V1 || state.onlineRoomCode.isEmpty()) return
        firebaseManager.updatePlayerState(
            roomCode = state.onlineRoomCode,
            isPlayer1 = state.isPlayer1,
            board = state.player.board,
            score = state.player.score,
            lines = state.player.linesCleared,
            isGameOver = state.player.isGameOver
        )
    }

    private fun onMatchVictory() {
        if (_gameState.value.matchStatus == MatchStatus.VICTORY) return
        soundManager.playVictory()
        val durationSec = ((System.currentTimeMillis() - matchStartTimeMs) / 1000).coerceAtLeast(1)
        val modeStr = if (_gameState.value.gameMode == GameMode.VS_CPU) {
            "VS CPU (${_gameState.value.cpuDifficulty.displayName})"
        } else {
            "ONLINE 1V1"
        }

        val record = MatchRecord(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            gameMode = modeStr,
            isVictory = true,
            linesCleared = _gameState.value.player.linesCleared,
            attacksSent = totalAttacksSentCounter,
            durationSeconds = durationSec,
            score = _gameState.value.player.score,
            maxCombo = _gameState.value.player.combo
        )

        matchHistoryManager.saveMatch(record)

        val pName = getPlayerName()
        firebaseManager.submitRankingProgress(pName, _gameState.value.player.score, _gameState.value.player.level, isVictory = true)
        
        if (_gameState.value.gameMode == GameMode.VS_CPU) {
            updateMissionProgress("m2", 1)
        }

        if (_gameState.value.gameMode == GameMode.ONLINE_1V1) {
            val newPl = (_gameState.value.pl + 20).coerceAtLeast(0)
            firebaseManager.updatePlayerPoints(pName, newPl)
            _gameState.update { it.copy(pl = newPl) }
        }

        _gameState.update {
            it.copy(
                matchStatus = MatchStatus.VICTORY,
                wins = it.wins + 1,
                matchDurationSeconds = durationSec,
                totalAttacksSent = totalAttacksSentCounter
            )
        }
        awardMatchCoins(isOnline = _gameState.value.gameMode == GameMode.ONLINE_1V1)
    }

    private fun onMatchDefeat() {
        if (_gameState.value.matchStatus == MatchStatus.DEFEAT) return
        soundManager.playGameOver()
        val durationSec = ((System.currentTimeMillis() - matchStartTimeMs) / 1000).coerceAtLeast(1)
        val modeStr = if (_gameState.value.gameMode == GameMode.VS_CPU) {
            "VS CPU (${_gameState.value.cpuDifficulty.displayName})"
        } else {
            "ONLINE 1V1"
        }

        val record = MatchRecord(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            gameMode = modeStr,
            isVictory = false,
            linesCleared = _gameState.value.player.linesCleared,
            attacksSent = totalAttacksSentCounter,
            durationSeconds = durationSec,
            score = _gameState.value.player.score,
            maxCombo = _gameState.value.player.combo
        )

        matchHistoryManager.saveMatch(record)

        val pName = getPlayerName()
        firebaseManager.submitRankingProgress(pName, _gameState.value.player.score, _gameState.value.player.level, isVictory = false)
        
        if (_gameState.value.gameMode == GameMode.ONLINE_1V1) {
            val newPl = (_gameState.value.pl - 10).coerceAtLeast(0)
            firebaseManager.updatePlayerPoints(pName, newPl)
            _gameState.update { it.copy(pl = newPl) }
        }

        _gameState.update {
            it.copy(
                matchStatus = MatchStatus.DEFEAT,
                losses = it.losses + 1,
                matchDurationSeconds = durationSec,
                totalAttacksSent = totalAttacksSentCounter,
                player = it.player.copy(isGameOver = true)
            )
        }
        if (_gameState.value.gameMode == GameMode.VS_CPU) {
            awardMatchCoins(isOnline = false)
        }
    }

    // ==========================================
    // PLAYER CONTROLS
    // ==========================================

    fun moveLeft() {
        if (_gameState.value.matchStatus != MatchStatus.PLAYING) return
        val player = _gameState.value.player
        val piece = player.currentPiece ?: return

        val moved = TetrisEngine.tryMove(player.board, piece, -1, 0)
        if (moved != null) {
            val ghost = TetrisEngine.calculateGhost(player.board, moved)
            _gameState.update { it.copy(player = player.copy(currentPiece = moved, ghostPiece = ghost)) }
            soundManager.playMove()
        }
    }

    fun moveRight() {
        if (_gameState.value.matchStatus != MatchStatus.PLAYING) return
        val player = _gameState.value.player
        val piece = player.currentPiece ?: return

        val moved = TetrisEngine.tryMove(player.board, piece, 1, 0)
        if (moved != null) {
            val ghost = TetrisEngine.calculateGhost(player.board, moved)
            _gameState.update { it.copy(player = player.copy(currentPiece = moved, ghostPiece = ghost)) }
            soundManager.playMove()
        }
    }

    fun rotate() {
        if (_gameState.value.matchStatus != MatchStatus.PLAYING) return
        val player = _gameState.value.player
        val piece = player.currentPiece ?: return

        val rotated = TetrisEngine.tryRotate(player.board, piece)
        if (rotated != null) {
            val ghost = TetrisEngine.calculateGhost(player.board, rotated)
            _gameState.update { it.copy(player = player.copy(currentPiece = rotated, ghostPiece = ghost)) }
            soundManager.playRotate()
        }
    }

    fun softDrop() {
        if (_gameState.value.matchStatus != MatchStatus.PLAYING) return
        val player = _gameState.value.player
        val piece = player.currentPiece ?: return

        val moved = TetrisEngine.tryMove(player.board, piece, 0, 1)
        if (moved != null) {
            _gameState.update {
                it.copy(
                    player = player.copy(
                        currentPiece = moved,
                        score = player.score + 1
                    )
                )
            }
        } else {
            viewModelScope.launch {
                lockPlayerPiece()
            }
        }
    }

    fun hardDrop() {
        if (_gameState.value.matchStatus != MatchStatus.PLAYING) return
        val player = _gameState.value.player
        val piece = player.currentPiece ?: return

        val ghost = TetrisEngine.calculateGhost(player.board, piece)
        val dropDistance = ghost.y - piece.y
        _gameState.update {
            it.copy(
                player = player.copy(
                    currentPiece = ghost,
                    score = player.score + (dropDistance * 2)
                )
            )
        }
        soundManager.playDrop()
        viewModelScope.launch {
            lockPlayerPiece()
        }
    }

    fun holdPiece() {
        if (_gameState.value.matchStatus != MatchStatus.PLAYING) return
        val player = _gameState.value.player
        val current = player.currentPiece ?: return
        if (!player.canHold) return

        soundManager.playRotate()

        val nextHold = current.type
        val pieceToSpawn = player.holdPiece ?: player.nextPiece
        val newNext = if (player.holdPiece == null) nextPlayerPiece() else player.nextPiece
        val newCurrent = Tetromino.spawn(pieceToSpawn)
        val ghost = TetrisEngine.calculateGhost(player.board, newCurrent)

        _gameState.update {
            it.copy(
                player = player.copy(
                    currentPiece = newCurrent,
                    ghostPiece = ghost,
                    holdPiece = nextHold,
                    nextPiece = newNext,
                    canHold = false
                )
            )
        }
    }

    fun toggleAudio() {
        val newState = !soundManager.isEnabled
        soundManager.isEnabled = newState
        if (newState && _gameState.value.matchStatus == MatchStatus.PLAYING) {
            startBgmWithEquipped()
        } else {
            soundManager.stopBgm()
        }
        _gameState.update { it.copy(isAudioEnabled = newState) }
    }

    fun togglePause() {
        val currentStatus = _gameState.value.matchStatus
        if (currentStatus == MatchStatus.PLAYING) {
            soundManager.stopBgm()
            _gameState.update { it.copy(matchStatus = MatchStatus.PAUSED) }
        } else if (currentStatus == MatchStatus.PAUSED) {
            startBgmWithEquipped()
            _gameState.update { it.copy(matchStatus = MatchStatus.PLAYING) }
        }
    }

    private fun startGarbageFallingLoop() {
        garbageFallingJob?.cancel()
        garbageFallingJob = viewModelScope.launch {
            while (true) {
                val state = _gameState.value
                if (state.matchStatus == MatchStatus.PLAYING) {

                    if (state.player.fallingGarbagePieces.isNotEmpty()) {
                        val result = TetrisEngine.stepFallingGarbagePieces(
                            state.player.board,
                            state.player.fallingGarbagePieces
                        )

                        val updatedPending = result.remainingFalling.sumOf { it.size }
                        val ghost = state.player.currentPiece?.let {
                            TetrisEngine.calculateGhost(result.newBoard, it)
                        }

                        _gameState.update {
                            it.copy(
                                player = it.player.copy(
                                    board = result.newBoard,
                                    fallingGarbagePieces = result.remainingFalling,
                                    pendingGarbage = updatedPending,
                                    ghostPiece = ghost
                                )
                            )
                        }

                        if (result.isTopOut) {
                            onMatchDefeat()
                        }
                    }

                    if (state.gameMode == GameMode.VS_CPU && state.opponent.fallingGarbagePieces.isNotEmpty()) {
                        val result = TetrisEngine.stepFallingGarbagePieces(
                            state.opponent.board,
                            state.opponent.fallingGarbagePieces
                        )

                        val updatedPending = result.remainingFalling.sumOf { it.size }

                        _gameState.update {
                            it.copy(
                                opponent = it.opponent.copy(
                                    board = result.newBoard,
                                    fallingGarbagePieces = result.remainingFalling,
                                    pendingGarbage = updatedPending
                                )
                            )
                        }

                        if (result.isTopOut) {
                            onMatchVictory()
                        }
                    }

                    if (state.gameMode == GameMode.ONLINE_1V1) {
                        syncOnlinePlayerState()
                    }
                }
                delay(50)
            }
        }
    }

    private fun startPlayerLoop() {
        playerLoopJob?.cancel()
        playerLoopJob = viewModelScope.launch {
            while (true) {
                val state = _gameState.value
                if (state.matchStatus == MatchStatus.PLAYING) {
                    val player = state.player
                    val piece = player.currentPiece

                    if (piece != null) {
                        val moved = TetrisEngine.tryMove(player.board, piece, 0, 1)
                        if (moved != null) {
                            _gameState.update { it.copy(player = player.copy(currentPiece = moved)) }
                        } else {
                            lockPlayerPiece()
                        }
                    }
                    val speed = (800 - ((player.level - 1) * 60)).coerceAtLeast(100).toLong()
                    delay(speed)
                } else {
                    delay(250)
                }
            }
        }
    }

    private suspend fun lockPlayerPiece() {
        val currentState = _gameState.value
        val player = currentState.player
        val piece = player.currentPiece ?: return

        soundManager.playDrop()

        val lockResult = TetrisEngine.lockPiece(player.board, piece)
        val boardWithPiece = lockResult.boardWithPiece
        val newBoard = lockResult.newBoard
        val cleared = lockResult.clearedRows.size

        if (cleared > 0) {
            // First update: show board WITH the piece before clearing
            _gameState.update {
                it.copy(
                    player = player.copy(
                        board = boardWithPiece,
                        currentPiece = null, // Remove active piece
                        clearingRows = lockResult.clearedRows,
                        isClearingLines = true,
                        lastClearTime = System.currentTimeMillis()
                    )
                )
            }

            soundManager.playLineClear(cleared)
            if (cleared >= 3) {
                particleController.triggerExplosion(200f, 400f, count = 50)
            }
            updateMissionProgress("m1", cleared)
            if (cleared == 4) {
                updateMissionProgress("m3", 1)
            }

            // Sync intermediate state if online
            if (_gameState.value.gameMode == GameMode.ONLINE_1V1) {
                syncOnlinePlayerState()
            }

            // WAIT for animation
            delay(400)
        }

        val newLines = player.linesCleared + cleared
        val newScore = player.score + when (cleared) {
            1 -> 100
            2 -> 300
            3 -> 600
            4 -> 1200
            else -> 0
        }
        val newLevel = (newLines / 10) + 1
        val newCombo = if (cleared > 0) player.combo + 1 else 0

        val attackBlocks = TetrisEngine.calculateAttackBlocks(cleared, newCombo)
        if (attackBlocks > 0) {
            totalAttacksSentCounter += attackBlocks
        }

        val opponent = currentState.opponent
        val newOpponentFalling = if (attackBlocks > 0) {
            _gameState.update {
                it.copy(
                    attackEvents = (it.attackEvents + AttackEvent(blocks = attackBlocks, fromPlayer = true)).takeLast(4)
                )
            }
            if (currentState.gameMode == GameMode.VS_CPU) {
                soundManager.playGarbageIncoming()
                TetrisEngine.createFallingGarbagePieceWave(opponent.board, opponent.fallingGarbagePieces, attackBlocks)
            } else {
                firebaseManager.sendAttackToOpponent(
                    currentState.onlineRoomCode,
                    currentState.isPlayer1,
                    attackBlocks
                )
                emptyList()
            }
        } else emptyList()

        if (lockResult.isTopOut) {
            onMatchDefeat()
            return
        }

        val nextType = player.nextPiece
        val upcomingType = nextPlayerPiece()
        val spawned = Tetromino.spawn(nextType)

        val canSpawn = TetrisEngine.isValidPosition(newBoard, spawned)
        if (!canSpawn) {
            onMatchDefeat()
            return
        }

        val ghost = TetrisEngine.calculateGhost(newBoard, spawned)
        val updatedOpponentFalling = opponent.fallingGarbagePieces + newOpponentFalling
        val updatedOpponentPending = updatedOpponentFalling.sumOf { it.size }

        _gameState.update {
            it.copy(
                player = player.copy(
                    board = newBoard,
                    currentPiece = spawned,
                    ghostPiece = ghost,
                    nextPiece = upcomingType,
                    canHold = true,
                    score = newScore,
                    linesCleared = newLines,
                    level = newLevel,
                    combo = newCombo,
                    clearingRows = emptyList(),
                    isClearingLines = false,
                    lastClearCount = cleared,
                    lastClearTime = System.currentTimeMillis()
                ),
                opponent = opponent.copy(
                    fallingGarbagePieces = updatedOpponentFalling,
                    pendingGarbage = updatedOpponentPending
                )
            )
        }

        if (_gameState.value.gameMode == GameMode.ONLINE_1V1) {
            syncOnlinePlayerState()
        }
    }

    private fun startOpponentLoop() {
        opponentLoopJob?.cancel()
        opponentLoopJob = viewModelScope.launch {
            while (true) {
                val state = _gameState.value
                if (state.gameMode != GameMode.VS_CPU) {
                    break
                }

                if (state.matchStatus == MatchStatus.PLAYING) {
                    val opponent = state.opponent
                    val piece = opponent.currentPiece
                    val difficulty = state.cpuDifficulty

                    if (piece != null) {
                        val decision = opponentAI.findBestMove(opponent.board, piece.type, difficulty)

                        val stepDelay = difficulty.stepDelayMs
                        val dropDelay = difficulty.dropDelayMs

                        var currentRotPiece: Tetromino = piece
                        while (currentRotPiece.rotation != decision.targetRotation) {
                            val nextRot = TetrisEngine.tryRotate(opponent.board, currentRotPiece)
                            if (nextRot != null) {
                                currentRotPiece = nextRot
                                _gameState.update { it.copy(opponent = it.opponent.copy(currentPiece = nextRot)) }
                            } else {
                                break
                            }
                            delay(stepDelay)
                        }

                        var currentPosPiece: Tetromino = currentRotPiece
                        while (currentPosPiece.x != decision.targetX) {
                            val dx = if (decision.targetX > currentPosPiece.x) 1 else -1
                            val moved = TetrisEngine.tryMove(opponent.board, currentPosPiece, dx, 0)
                            if (moved != null) {
                                currentPosPiece = moved
                                _gameState.update { it.copy(opponent = it.opponent.copy(currentPiece = moved)) }
                            } else {
                                break
                            }
                            delay(stepDelay)
                        }

                        while (true) {
                            val movedDown = TetrisEngine.tryMove(opponent.board, currentPosPiece, 0, 1)
                            if (movedDown != null) {
                                currentPosPiece = movedDown
                                _gameState.update { it.copy(opponent = it.opponent.copy(currentPiece = movedDown)) }
                                delay(dropDelay)
                            } else {
                                break
                            }
                        }

                        lockOpponentPiece()
                        delay(stepDelay * 2)
                    } else {
                        delay(150)
                    }
                } else {
                    delay(250)
                }
            }
        }
    }

    private suspend fun lockOpponentPiece() {
        val currentState = _gameState.value
        val opponent = currentState.opponent
        val piece = opponent.currentPiece ?: return

        val lockResult = TetrisEngine.lockPiece(opponent.board, piece)
        val boardWithPiece = lockResult.boardWithPiece
        val newBoard = lockResult.newBoard
        val cleared = lockResult.clearedRows.size

        if (cleared > 0) {
            // First update: show board WITH the piece before clearing
            _gameState.update {
                it.copy(
                    opponent = opponent.copy(
                        board = boardWithPiece,
                        currentPiece = null,
                        clearingRows = lockResult.clearedRows,
                        isClearingLines = true,
                        lastClearTime = System.currentTimeMillis()
                    )
                )
            }
            // WAIT for animation
            delay(400)
        }
        val newLines = opponent.linesCleared + cleared
        val newScore = opponent.score + when (cleared) {
            1 -> 100
            2 -> 300
            3 -> 600
            4 -> 1200
            else -> 0
        }
        val newCombo = if (cleared > 0) opponent.combo + 1 else 0

        val attackBlocks = TetrisEngine.calculateAttackBlocks(cleared, newCombo)

        val player = currentState.player
        val newPlayerFalling = if (attackBlocks > 0) {
            soundManager.playGarbageIncoming()
            _gameState.update {
                it.copy(
                    attackEvents = (it.attackEvents + AttackEvent(blocks = attackBlocks, fromPlayer = false)).takeLast(4)
                )
            }
            TetrisEngine.createFallingGarbagePieceWave(player.board, player.fallingGarbagePieces, attackBlocks)
        } else emptyList()

        if (lockResult.isTopOut) {
            onMatchVictory()
            return
        }

        val nextType = opponent.nextPiece
        val upcomingType = nextOpponentPiece()
        val spawned = Tetromino.spawn(nextType)

        val canSpawn = TetrisEngine.isValidPosition(newBoard, spawned)
        if (!canSpawn) {
            onMatchVictory()
            return
        }

        val updatedPlayerFalling = player.fallingGarbagePieces + newPlayerFalling
        val updatedPlayerPending = updatedPlayerFalling.sumOf { it.size }

        _gameState.update {
            it.copy(
                opponent = opponent.copy(
                    board = newBoard,
                    currentPiece = spawned,
                    nextPiece = upcomingType,
                    canHold = true,
                    score = newScore,
                    linesCleared = newLines,
                    combo = newCombo,
                    clearingRows = emptyList(),
                    isClearingLines = false,
                    lastClearCount = cleared,
                    lastClearTime = System.currentTimeMillis()
                ),
                player = player.copy(
                    fallingGarbagePieces = updatedPlayerFalling,
                    pendingGarbage = updatedPlayerPending
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerLoopJob?.cancel()
        opponentLoopJob?.cancel()
        garbageFallingJob?.cancel()
        val currentCode = _gameState.value.onlineRoomCode
        if (currentCode.isNotEmpty() && _gameState.value.isPlayer1) {
            firebaseManager.deleteRoom(currentCode)
        }
        firebaseManager.stopRoomListener()
    }
}
