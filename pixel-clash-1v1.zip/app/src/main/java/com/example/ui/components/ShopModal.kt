package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.PlayerInventory
import com.example.model.ShopItem

@Composable
fun ShopModal(
    inventory: PlayerInventory,
    items: List<ShopItem>,
    onBuyItem: (ShopItem) -> Unit,
    onEquipItem: (ShopItem) -> Unit,
    onClose: () -> Unit
) {
    var selectedTabIndex by remember { mutableStateOf(0) }
    val categories = listOf("🧊 BLOCOS", "🖼️ FUNDOS", "💥 EFEITOS", "🎵 MÚSICAS")
    val categoryKeys = listOf("blocos", "fundos", "efeitos", "musicas")
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val maxModalHeight = minOf(screenHeight * 0.75f, screenHeight - 140.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.90f)
                .widthIn(max = 440.dp)
                .heightIn(max = maxModalHeight)
                .wrapContentHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F1224))
                .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("LOJA", color = Color(0xFF00E5FF), fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                    Text("🪙 ${inventory.coins}", color = Color(0xFFFFD600), fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                TabRow(selectedTabIndex = selectedTabIndex, containerColor = Color.Transparent, contentColor = Color.White) {
                    categories.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = { Text(title, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val filteredItems = items.filter { it.itemCategory == categoryKeys[selectedTabIndex] }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredItems.size) { index ->
                        val item = filteredItems[index]
                        ShopItemCard(
                            item = item,
                            isBought = inventory.boughtItems.contains(item.id),
                            isEquipped = inventory.equippedItems[item.itemCategory] == item.id,
                            onBuy = { onBuyItem(item) },
                            onEquip = { onEquipItem(item) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E355B)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("FECHAR", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun ShopItemCard(
    item: ShopItem,
    isBought: Boolean,
    isEquipped: Boolean,
    onBuy: () -> Unit,
    onEquip: () -> Unit
) {
    Column(
        modifier = Modifier
            .border(1.dp, if (isEquipped) Color(0xFF00E676) else Color(0xFF4A5568), RoundedCornerShape(8.dp))
            .background(Color(0xFF1A1F3C), RoundedCornerShape(8.dp))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(item.name, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))
        Text("${item.price} Coins", color = Color(0xFFFFD600), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        if (isEquipped) {
            Text("EQUIPADO", color = Color(0xFF00E676), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        } else if (isBought) {
            Button(onClick = onEquip, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF))) {
                Text("EQUIPAR", fontSize = 10.sp)
            }
        } else {
            Button(onClick = onBuy, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))) {
                Text("COMPRAR", fontSize = 10.sp, color = Color.Black)
            }
        }
    }
}
