package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Cell
import com.example.model.PlayerState

@Composable
fun MiniBoardCanvas(
    opponentState: PlayerState,
    modifier: Modifier = Modifier,
    skinId: String = "neon"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier
            .testTag("mini_board_wrapper")
            .shadow(8.dp, RoundedCornerShape(8.dp), spotColor = Color(0xFFFF1744))
            .border(
                width = 2.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFFFF2A85),
                        Color(0xFFFF1744),
                        Color(0xFF880E4F)
                    )
                ),
                shape = RoundedCornerShape(8.dp)
            )
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF130919))
            .padding(4.dp)
    ) {
        // Opponent header banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF1744).copy(alpha = pulseAlpha))
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "RIVAL CPU",
                color = Color(0xFFFF4081),
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "${opponentState.linesCleared}L",
                color = Color(0xFFFFD600),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Mini 10x20 Grid
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(10f / 20f)
                .background(Color(0xFF09060E))
                .clip(RoundedCornerShape(4.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize().testTag("opponent_mini_canvas")) {
                val blockSize = size.width / PlayerState.BOARD_COLS
                val boardWidth = size.width
                val boardHeight = size.height

                // Grid lines (faint)
                val gridColor = Color(0xFF1F1226)
                for (c in 1 until PlayerState.BOARD_COLS) {
                    val x = c * blockSize
                    drawLine(
                        color = gridColor,
                        start = Offset(x, 0f),
                        end = Offset(x, boardHeight),
                        strokeWidth = 0.5f
                    )
                }

                // Locked cells
                val now = System.currentTimeMillis()
                val clearAnimDuration = 400f

                for (r in 0 until PlayerState.BOARD_ROWS) {
                    val isRowClearing = opponentState.isClearingLines && opponentState.clearingRows.contains(r)
                    val rowAlpha = if (isRowClearing) {
                        (1.0f - (now - opponentState.lastClearTime) / clearAnimDuration).coerceIn(0f, 1f)
                    } else 1.0f

                    for (c in 0 until PlayerState.BOARD_COLS) {
                        val cell = opponentState.board[r][c]
                        if (cell != null) {
                            PixelBlockDrawer.drawPixelBlock(
                                drawScope = this,
                                topLeft = Offset(c * blockSize, r * blockSize),
                                blockSize = blockSize,
                                cell = cell,
                                skinId = skinId,
                                alpha = rowAlpha
                            )
                        }
                    }
                }

                // Line clear flash effect for opponent
                if (opponentState.clearingRows.isNotEmpty() && now - opponentState.lastClearTime < 250) {
                    val progress = (now - opponentState.lastClearTime) / 250f
                    val flashAlpha = (1f - progress).coerceIn(0f, 1f)
                    for (r in opponentState.clearingRows) {
                        drawRect(
                            color = Color.White.copy(alpha = flashAlpha * 0.7f),
                            topLeft = Offset(0f, r * blockSize),
                            size = Size(boardWidth, blockSize)
                        )
                    }
                }

                // Falling 1x2 and 1x3 garbage pieces on opponent board
                for (fp in opponentState.fallingGarbagePieces) {
                    if (fp.spawnDelayTicks == 0 && fp.y in 0 until PlayerState.BOARD_ROWS) {
                        val endCol = (fp.startCol + fp.size).coerceAtMost(PlayerState.BOARD_COLS)
                        for (c in fp.startCol until endCol) {
                            PixelBlockDrawer.drawPixelBlock(
                                drawScope = this,
                                topLeft = Offset(c * blockSize, fp.y * blockSize),
                                blockSize = blockSize,
                                cell = Cell.GARBAGE,
                                skinId = skinId
                            )
                        }
                    }
                }

                // Opponent active piece
                val current = opponentState.currentPiece
                if (current != null) {
                    val activeCell = Cell.fromPiece(current.type)
                    for ((cx, cy) in current.getOccupiedCoordinates()) {
                        if (cy in 0 until PlayerState.BOARD_ROWS && cx in 0 until PlayerState.BOARD_COLS) {
                            PixelBlockDrawer.drawPixelBlock(
                                drawScope = this,
                                topLeft = Offset(cx * blockSize, cy * blockSize),
                                blockSize = blockSize,
                                cell = activeCell,
                                skinId = skinId
                            )
                        }
                    }
                }

                // Opponent pending garbage
                if (opponentState.pendingGarbage > 0) {
                    val meterWidth = 3f
                    val garbageHeight = (opponentState.pendingGarbage * (blockSize / 5f)).coerceAtMost(boardHeight)
                    drawRect(
                        color = Color(0xFFFF5252).copy(alpha = pulseAlpha),
                        topLeft = Offset(0f, boardHeight - garbageHeight),
                        size = Size(meterWidth, garbageHeight)
                    )
                }
            }
        }
    }
}
