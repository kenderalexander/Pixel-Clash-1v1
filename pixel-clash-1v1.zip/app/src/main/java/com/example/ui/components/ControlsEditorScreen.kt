package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.KeyboardDoubleArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ButtonPos
import com.example.model.ControlSettings
import kotlin.math.roundToInt

@Composable
fun ControlsEditorScreen(
    initialSettings: ControlSettings,
    onSaveSettings: (ControlSettings) -> Unit,
    onResetDefaults: () -> ControlSettings,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(initialSettings.scale) }
    var opacity by remember { mutableFloatStateOf(initialSettings.opacity) }
    var buttonGap by remember { mutableFloatStateOf(initialSettings.buttonGap) }

    var posLeft by remember { mutableStateOf(initialSettings.posLeft) }
    var posRotate by remember { mutableStateOf(initialSettings.posRotate) }
    var posRight by remember { mutableStateOf(initialSettings.posRight) }
    var posSoftDrop by remember { mutableStateOf(initialSettings.posSoftDrop) }
    var posHardDrop by remember { mutableStateOf(initialSettings.posHardDrop) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070914))
            .testTag("controls_editor_screen")
    ) {
        // Retro Touch Editor Grid
        Canvas(modifier = Modifier.fillMaxSize()) {
            val gridStep = 32.dp.toPx()
            val w = size.width
            val h = size.height
            val gridColor = Color(0xFF161A36)

            var x = 0f
            while (x < w) {
                drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                x += gridStep
            }
            var y = 0f
            while (y < h) {
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                y += gridStep
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP PANEL: Header & Sliders
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1329))
                    .padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "⚙ EDITOR DE LAYOUT DOS CONTROLES",
                        color = Color(0xFF00E5FF),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Arraste os botões para mover • Ajuste tamanho, opacidade e espaçamento",
                        color = Color(0xFF80DEEA),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    // SLIDER 1: Scale (80% to 150%)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TAMANHO: ${(scale * 100).roundToInt()}%",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(110.dp)
                        )
                        Slider(
                            value = scale,
                            onValueChange = { scale = it },
                            valueRange = 0.8f..1.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFFD600),
                                activeTrackColor = Color(0xFFFFD600),
                                inactiveTrackColor = Color(0xFF232B52)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // SLIDER 2: Opacity (30% to 100%)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OPACIDADE: ${(opacity * 100).roundToInt()}%",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(110.dp)
                        )
                        Slider(
                            value = opacity,
                            onValueChange = { opacity = it },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E676),
                                activeTrackColor = Color(0xFF00E676),
                                inactiveTrackColor = Color(0xFF232B52)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // SLIDER 3: Spacing Gap (4dp to 24dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ESPAÇAMENTO: ${buttonGap.roundToInt()}dp",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(110.dp)
                        )
                        Slider(
                            value = buttonGap,
                            onValueChange = { buttonGap = it },
                            valueRange = 4f..24f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF),
                                inactiveTrackColor = Color(0xFF232B52)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // MIDDLE AREA: Drag & Drop Interactive Canvas Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 12.dp)
                    .border(1.dp, Color(0xFF2A335B), RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0B0E1E)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .alpha(opacity),
                    verticalArrangement = Arrangement.spacedBy(buttonGap.dp)
                ) {
                    // Row 1: Left, Rotate, Right
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(buttonGap.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DraggableEditorButton(
                            label = "ESQUERDA",
                            icon = Icons.AutoMirrored.Filled.ArrowBack,
                            baseColor = Color(0xFF1E88E5),
                            pos = posLeft,
                            scale = scale,
                            onDrag = { dx, dy -> posLeft = ButtonPos(posLeft.x + dx, posLeft.y + dy) },
                            modifier = Modifier.weight(1f)
                        )

                        DraggableEditorButton(
                            label = "GIRAR",
                            icon = Icons.Default.Refresh,
                            baseColor = Color(0xFF7C4DFF),
                            pos = posRotate,
                            scale = scale,
                            onDrag = { dx, dy -> posRotate = ButtonPos(posRotate.x + dx, posRotate.y + dy) },
                            modifier = Modifier.weight(1f)
                        )

                        DraggableEditorButton(
                            label = "DIREITA",
                            icon = Icons.AutoMirrored.Filled.ArrowForward,
                            baseColor = Color(0xFF1E88E5),
                            pos = posRight,
                            scale = scale,
                            onDrag = { dx, dy -> posRight = ButtonPos(posRight.x + dx, posRight.y + dy) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 2: Soft Drop, Hard Drop (Centered/Wider)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(buttonGap.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(modifier = Modifier.weight(0.2f))

                        DraggableEditorButton(
                            label = "BAIXAR",
                            icon = Icons.Default.ArrowDownward,
                            baseColor = Color(0xFF00ACC1),
                            pos = posSoftDrop,
                            scale = scale,
                            onDrag = { dx, dy -> posSoftDrop = ButtonPos(posSoftDrop.x + dx, posSoftDrop.y + dy) },
                            modifier = Modifier.weight(1.3f)
                        )

                        DraggableEditorButton(
                            label = "QUEDA",
                            icon = Icons.Default.KeyboardDoubleArrowDown,
                            baseColor = Color(0xFFFFB300),
                            pos = posHardDrop,
                            scale = scale,
                            onDrag = { dx, dy -> posHardDrop = ButtonPos(posHardDrop.x + dx, posHardDrop.y + dy) },
                            modifier = Modifier.weight(1.3f)
                        )

                        Spacer(modifier = Modifier.weight(0.2f))
                    }
                }
            }

            // BOTTOM ACTION BAR: Restore, Save, Cancel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // RESET DEFAULTS
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .border(1.dp, Color(0xFFFF5252), RoundedCornerShape(8.dp))
                        .background(Color(0xFF381216), RoundedCornerShape(8.dp))
                        .clickable {
                            val reset = onResetDefaults()
                            scale = reset.scale
                            opacity = reset.opacity
                            buttonGap = reset.buttonGap
                            posLeft = reset.posLeft
                            posRotate = reset.posRotate
                            posRight = reset.posRight
                            posSoftDrop = reset.posSoftDrop
                            posHardDrop = reset.posHardDrop
                        }
                        .testTag("reset_controls_button")
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Restore,
                            contentDescription = "Restaurar",
                            tint = Color(0xFFFF5252),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RESTAURAR",
                            color = Color(0xFFFF5252),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // CANCEL
                Box(
                    modifier = Modifier
                        .weight(0.9f)
                        .height(48.dp)
                        .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                        .clickable { onCancel() }
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CANCELAR",
                        color = Color.LightGray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // SAVE
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp)
                        .background(Color(0xFF00E676), RoundedCornerShape(8.dp))
                        .clickable {
                            val updated = ControlSettings(
                                scale = scale,
                                opacity = opacity,
                                posLeft = posLeft,
                                posRotate = posRotate,
                                posRight = posRight,
                                posSoftDrop = posSoftDrop,
                                posHardDrop = posHardDrop,
                                buttonGap = buttonGap
                            )
                            onSaveSettings(updated)
                        }
                        .testTag("save_controls_button")
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Salvar",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "SALVAR",
                            color = Color.Black,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DraggableEditorButton(
    label: String,
    icon: ImageVector,
    baseColor: Color,
    pos: ButtonPos,
    scale: Float,
    onDrag: (dx: Float, dy: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val btnHeight = (56 * scale).dp

    Box(
        modifier = modifier
            .offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            }
            .height(btnHeight)
            .border(
                width = 2.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White, baseColor)
                ),
                shape = RoundedCornerShape(10.dp)
            )
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(baseColor, baseColor.copy(alpha = 0.7f), Color(0xFF101326))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size((22 * scale).dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = (9 * scale).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}
