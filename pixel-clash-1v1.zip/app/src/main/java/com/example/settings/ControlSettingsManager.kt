package com.example.settings

import android.content.Context
import com.example.model.ButtonPos
import com.example.model.ControlSettings

class ControlSettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("pixel_clash_controls_prefs", Context.MODE_PRIVATE)

    fun loadSettings(): ControlSettings {
        return ControlSettings(
            scale = prefs.getFloat("scale", 1.0f),
            opacity = prefs.getFloat("opacity", 1.0f),
            posLeft = ButtonPos(prefs.getFloat("posLeftX", 0f), prefs.getFloat("posLeftY", 0f)),
            posRotate = ButtonPos(prefs.getFloat("posRotateX", 0f), prefs.getFloat("posRotateY", 0f)),
            posRight = ButtonPos(prefs.getFloat("posRightX", 0f), prefs.getFloat("posRightY", 0f)),
            posHold = ButtonPos(prefs.getFloat("posHoldX", 0f), prefs.getFloat("posHoldY", 0f)),
            posSoftDrop = ButtonPos(prefs.getFloat("posSoftDropX", 0f), prefs.getFloat("posSoftDropY", 0f)),
            posHardDrop = ButtonPos(prefs.getFloat("posHardDropX", 0f), prefs.getFloat("posHardDropY", 0f)),
            buttonGap = prefs.getFloat("buttonGap", 8.0f)
        )
    }

    fun saveSettings(settings: ControlSettings) {
        prefs.edit().apply {
            putFloat("scale", settings.scale)
            putFloat("opacity", settings.opacity)
            putFloat("posLeftX", settings.posLeft.x)
            putFloat("posLeftY", settings.posLeft.y)
            putFloat("posRotateX", settings.posRotate.x)
            putFloat("posRotateY", settings.posRotate.y)
            putFloat("posRightX", settings.posRight.x)
            putFloat("posRightY", settings.posRight.y)
            putFloat("posHoldX", settings.posHold.x)
            putFloat("posHoldY", settings.posHold.y)
            putFloat("posSoftDropX", settings.posSoftDrop.x)
            putFloat("posSoftDropY", settings.posSoftDrop.y)
            putFloat("posHardDropX", settings.posHardDrop.x)
            putFloat("posHardDropY", settings.posHardDrop.y)
            putFloat("buttonGap", settings.buttonGap)
            apply()
        }
    }

    fun getPlayerName(): String {
        return prefs.getString("playerName", "") ?: ""
    }

    fun savePlayerName(name: String) {
        prefs.edit().putString("playerName", name).apply()
    }

    fun getDeviceId(): String {
        var id = prefs.getString("deviceId", "") ?: ""
        if (id.isEmpty()) {
            id = java.util.UUID.randomUUID().toString()
            prefs.edit().putString("deviceId", id).apply()
        }
        return id
    }

    fun getPlayerPin(): String {
        return prefs.getString("playerPin", "") ?: ""
    }

    fun savePlayerPin(pin: String) {
        prefs.edit().putString("playerPin", pin).apply()
    }

    fun resetToDefaults(): ControlSettings {
        val name = getPlayerName()
        prefs.edit().clear().apply()
        savePlayerName(name) // Preserve player name across control resets
        return ControlSettings()
    }
}
